package com.archon.client.backup;

import android.os.ParcelFileDescriptor;

interface IWorldBackupService {
    String[] listWorlds();
    String exportWorld(String folderName, in ParcelFileDescriptor output);
    void destroy() = 16777114;
}