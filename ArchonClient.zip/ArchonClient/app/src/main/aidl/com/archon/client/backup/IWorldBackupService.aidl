package com.archon.client.backup;

// Все методы возвращают JSON-строку: {"ok":true,...} или {"ok":false,"code":"...","message":"..."}.
interface IWorldBackupService {
    String listWorlds() = 1;
    String backupWorld(String folderName, int keep, boolean force) = 2;
    String listBackups() = 3;
    String restoreBackup(String fileName) = 4;
    String deleteBackup(String fileName) = 5;
    void destroy() = 16777114;
}
