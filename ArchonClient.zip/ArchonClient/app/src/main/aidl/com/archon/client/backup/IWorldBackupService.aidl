package com.archon.client.backup;

import android.os.ParcelFileDescriptor;

interface IWorldBackupService {
    String[] listWorlds() = 1;
    String exportWorld(String folderName, in ParcelFileDescriptor output) = 2;
    void destroy() = 16777114;
}