package com.archon.client.mods

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.Collections
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/** Название, описание и картинка файла берутся из самого мода или мира. */
object ModMeta {
    data class Info(val title: String, val description: String, val image: File?)

    private class Scan(val title: String?, val desc: String)

    private val ICONS = setOf(
        "pack_icon.png", "pack_icon.jpg", "pack_icon.jpeg",
        "world_icon.jpeg", "world_icon.jpg", "world_icon.png",
    )
    private val LANG_KEY = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")
    private val FORMAT_CODES = Regex("§.")

    private fun dir(context: Context) = File(ModsRepository.modsDir(context), ".meta").also { it.mkdirs() }
    private fun imageFile(context: Context, fileName: String) = File(dir(context), "$fileName.png")
    private fun jsonFile(context: Context, fileName: String) = File(dir(context), "$fileName.json")

    fun remove(context: Context, fileName: String) {
        jsonFile(context, fileName).delete()
        imageFile(context, fileName).delete()
    }

    fun load(context: Context, file: File): Info {
        val json = jsonFile(context, file.name)
        val img = imageFile(context, file.name)
        val saved = if (json.isFile) runCatching { JSONObject(json.readText()) }.getOrNull() else null
        var title = saved?.optString("name").orEmpty()
        var desc = saved?.optString("description").orEmpty()

        // Первый раз читаем данные из архива и запоминаем, чтобы потом не открывать его снова
        if (saved == null || !saved.optBoolean("scanned", false)) {
            val scan = scan(file, img)
            if (title.isBlank()) title = scan.title.orEmpty()
            if (desc.isBlank()) desc = scan.desc
            runCatching {
                json.writeText(
                    JSONObject().put("name", title).put("description", desc).put("scanned", true).toString()
                )
            }
        }
        if (title.isBlank()) title = file.nameWithoutExtension
        return Info(title, desc, img.takeIf { it.isFile && it.length() > 0 })
    }

    private fun depth(e: ZipEntry) = e.name.count { it == '/' }
    private fun baseName(e: ZipEntry) = e.name.substringAfterLast('/').lowercase()

    private fun clean(s: String?): String? {
        val t = s?.replace(FORMAT_CODES, "")?.trim().orEmpty()
        // Если вместо текста ключ перевода (например, pack.name), его не показываем
        return if (t.isBlank() || LANG_KEY.matches(t)) null else t
    }

    private fun scan(src: File, imgOut: File): Scan {
        return try {
            ZipFile(src).use { zf ->
                val entries = Collections.list(zf.entries()).filter { !it.isDirectory }

                entries
                    .filter { it.size > 0 && it.size < 3_000_000 && baseName(it) in ICONS }
                    .minByOrNull { depth(it) }
                    ?.let { icon ->
                        zf.getInputStream(icon).use { input -> imgOut.outputStream().use { input.copyTo(it) } }
                    }

                val levelName = entries
                    .firstOrNull { it.name.equals("levelname.txt", ignoreCase = true) }
                    ?.let { e -> zf.getInputStream(e).bufferedReader().use { it.readLine() } }

                var manifestName: String? = null
                var manifestDesc = ""
                entries
                    .filter { baseName(it) == "manifest.json" }
                    .minByOrNull { depth(it) }
                    ?.let { e ->
                        val text = zf.getInputStream(e).bufferedReader().use { it.readText() }.trimStart('\uFEFF')
                        val header = JSONObject(text).optJSONObject("header")
                        manifestName = clean(header?.optString("name"))
                        manifestDesc = clean(header?.optString("description")).orEmpty()
                    }

                Scan(clean(levelName) ?: manifestName, manifestDesc)
            }
        } catch (e: Exception) {
            Scan(null, "")
        }
    }
}
