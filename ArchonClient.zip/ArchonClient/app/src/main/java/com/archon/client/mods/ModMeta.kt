package com.archon.client.mods

import android.content.Context
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Collections
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/** Название, описание и картинка файла берутся из самого мода или мира. */
object ModMeta {
    data class Info(val title: String, val description: String, val image: File?)

    private class Scan(val title: String?, val desc: String)

    private val ICONS = setOf(
        "pack_icon.png", "pack_icon.jpg", "pack_icon.jpeg",
        "world_icon.jpeg", "world_icon.jpg", "world_icon.png",
    )
    private val LANG_KEY = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")
    private val FORMAT_CODES = Regex("§.")

    private fun dir(context: Context) = File(ModsRepository.modsDir(context), ".meta").also { it.mkdirs() }
    private fun imageFile(context: Context, fileName: String) = File(dir(context), "$fileName.png")
    private fun jsonFile(context: Context, fileName: String) = File(dir(context), "$fileName.json")

    fun remove(context: Context, fileName: String) {
        jsonFile(context, fileName).delete()
        imageFile(context, fileName).delete()
    }

    private fun readJson(f: File): JSONObject? = if (f.isFile) runCatching { JSONObject(f.readText()) }.getOrNull() else null

    /** Файл в библиотеке, скачанный из облака как мод [cloudId], или null. */
    fun fileForCloud(context: Context, cloudId: String): File? {
        val lib = ModsRepository.modsDir(context)
        return dir(context).listFiles { f -> f.name.endsWith(".json") }?.firstNotNullOfOrNull { j ->
            val o = readJson(j) ?: return@firstNotNullOfOrNull null
            if (o.optString("cloud_id") != cloudId) return@firstNotNullOfOrNull null
            File(lib, j.name.removeSuffix(".json")).takeIf { it.isFile }
        }
    }

    /**
     * Что уже есть в библиотеке: «id:<мод>» для скачанных из облака
     * и «file:<имя>» для файлов, у которых нет отметки облака (добавлены вручную или скачаны до 0.8.5).
     */
    fun libraryKeys(context: Context): Set<String> {
        val keys = mutableSetOf<String>()
        ModsRepository.listAll(context).forEach { f ->
            val id = readJson(jsonFile(context, f.name))?.optString("cloud_id").orEmpty()
            keys += if (id.isNotBlank()) "id:$id" else "file:${f.name}"
        }
        return keys
    }

    fun load(context: Context, file: File): Info {
        val json = jsonFile(context, file.name)
        val img = imageFile(context, file.name)
        val saved = readJson(json)
        var title = saved?.optString("name").orEmpty()
        var desc = saved?.optString("description").orEmpty()

        // Первый раз читаем данные из архива и запоминаем, чтобы потом не открывать его снова
        if (saved == null || !saved.optBoolean("scanned", false)) {
            val scan = scan(file, img)
            if (title.isBlank()) title = scan.title.orEmpty()
            if (desc.isBlank()) desc = scan.desc
            runCatching {
                val o = JSONObject().put("name", title).put("description", desc).put("scanned", true)
                saved?.optString("cloud_id")?.takeIf { it.isNotBlank() }?.let { o.put("cloud_id", it) }
                json.writeText(o.toString())
            }
        }
        if (title.isBlank()) title = file.nameWithoutExtension
        return Info(title, desc, img.takeIf { it.isFile && it.length() > 0 })
    }

    /** Название, описание и картинка, которые автор указал в облаке. */
    fun saveCloud(context: Context, fileName: String, cloudId: String, title: String, desc: String, image: ByteArray?) {
        runCatching {
            jsonFile(context, fileName).writeText(
                JSONObject().put("name", title).put("description", desc).put("scanned", true)
                    .put("cloud_id", cloudId).toString()
            )
        }
        if (image != null && image.isNotEmpty()) runCatching { imageFile(context, fileName).writeBytes(image) }
    }

    private fun copyLimited(input: InputStream, out: OutputStream, max: Long) {
        val buf = ByteArray(8192)
        var total = 0L
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > max) throw IOException("слишком большой файл")
            out.write(buf, 0, n)
        }
    }

    private fun readLimited(zf: ZipFile, e: ZipEntry, max: Int): String {
        val out = ByteArrayOutputStream()
        zf.getInputStream(e).use { copyLimited(it, out, max.toLong()) }
        return out.toString("UTF-8")
    }

    private fun depth(e: ZipEntry) = e.name.count { it == '/' }
    private fun baseName(e: ZipEntry) = e.name.substringAfterLast('/').lowercase()

    private fun clean(s: String?): String? {
        val t = s?.replace(FORMAT_CODES, "")?.trim().orEmpty()
        // Если вместо текста ключ перевода (например, pack.name), его не показываем
        return if (t.isBlank() || LANG_KEY.matches(t)) null else t
    }

    private fun scan(src: File, imgOut: File): Scan {
        return try {
            ZipFile(src).use { zf ->
                val entries = Collections.list(zf.entries()).filter { !it.isDirectory }

                entries
                    .filter { it.size > 0 && it.size < 3_000_000 && baseName(it) in ICONS }
                    .minByOrNull { depth(it) }
                    ?.let { icon ->
                        zf.getInputStream(icon).use { input ->
                            imgOut.outputStream().use { out -> copyLimited(input, out, 3_000_000L) }
                        }
                    }

                val levelName = entries
                    .firstOrNull { it.name.equals("levelname.txt", ignoreCase = true) }
                    ?.let { e -> readLimited(zf, e, 4_000).lineSequence().firstOrNull() }

                var manifestName: String? = null
                var manifestDesc = ""
                entries
                    .filter { baseName(it) == "manifest.json" }
                    .minByOrNull { depth(it) }
                    ?.let { e ->
                        val text = readLimited(zf, e, 1_000_000).trimStart('\uFEFF')
                        val header = JSONObject(text).optJSONObject("header")
                        manifestName = clean(header?.optString("name"))
                        manifestDesc = clean(header?.optString("description")).orEmpty()
                    }

                Scan(clean(levelName) ?: manifestName, manifestDesc)
            }
        } catch (e: Exception) {
            imgOut.delete()
            Scan(null, "")
        }
    }
}
