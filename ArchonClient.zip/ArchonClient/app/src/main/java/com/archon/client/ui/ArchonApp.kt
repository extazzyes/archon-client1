package com.archon.client.ui

import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.archon.client.minecraft.MinecraftLauncher
import com.archon.client.mods.ModKind

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Главная", Icons.Filled.Home),
    Files("Файлы", Icons.AutoMirrored.Filled.List),
    Store("Моды", Icons.Filled.ShoppingCart),
    Chat("Чат", Icons.Filled.Email),
    Me("Профиль", Icons.Filled.Person),
}

@Composable
fun ArchonApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.Home) }
    var filesKind by remember { mutableStateOf(ModKind.Addons) }
    var showSettings by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(MinecraftLauncher.getStatus(context)) }

    // Когда открыта клавиатура, нижнее меню прячем, чтобы не занимало место
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    // Обновляем статус, когда возвращаемся в приложение (например, после установки игры)
    val lifecycle = (context as ComponentActivity).lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                status = MinecraftLauncher.getStatus(context)
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (!imeVisible) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item && !showSettings,
                            onClick = { showSettings = false; tab = item },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label, maxLines = 1) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        val modifier = Modifier.padding(padding).consumeWindowInsets(padding)
        if (showSettings) {
            BackHandler { showSettings = false }
            Column(modifier) {
                Row(Modifier.padding(start = 4.dp, top = 4.dp)) {
                    IconButton(onClick = { showSettings = false }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
                SettingsScreen(Modifier.weight(1f))
            }
        } else {
            when (tab) {
                Tab.Home -> HomeScreen(
                    status = status,
                    onPlay = {
                        if (!MinecraftLauncher.launch(context)) {
                            Toast.makeText(context, "Не удалось запустить Minecraft", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onInstall = { MinecraftLauncher.openStore(context) },
                    onOpenAddons = { filesKind = ModKind.Addons; tab = Tab.Files },
                    onOpenWorlds = { filesKind = ModKind.Worlds; tab = Tab.Files },
                    onOpenSettings = { showSettings = true },
                    modifier = modifier,
                )
                Tab.Files -> FilesScreen(filesKind, { filesKind = it }, modifier)
                Tab.Store -> StoreScreen(modifier) { tab = Tab.Me }
                Tab.Chat -> ChatScreen(modifier)
                Tab.Me -> ProfileScreen(modifier) { showSettings = true }
            }
        }
    }
}
