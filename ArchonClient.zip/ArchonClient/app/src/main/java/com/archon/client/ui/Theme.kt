package com.archon.client.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import com.archon.client.settings.AppSettings

val Ok = Color(0xFF34D399)
val Warn = Color(0xFFF59E0B)

@Composable
fun ArchonTheme(content: @Composable () -> Unit) {
    val accent = AppSettings.accent
    val amoled = AppSettings.amoled
    val bg = if (amoled) Color.Black else Color(0xFF0F1115)
    val surface = if (amoled) Color(0xFF111111) else Color(0xFF171A21)
    val variant = if (amoled) Color(0xFF1C1C1C) else Color(0xFF21252E)
    val container = accent.copy(alpha = 0.22f).compositeOver(surface)

    val scheme = darkColorScheme(
        primary = accent,
        onPrimary = Color.White,
        primaryContainer = container,
        onPrimaryContainer = Color.White,
        secondaryContainer = container,
        onSecondaryContainer = Color.White,
        background = bg,
        onBackground = Color(0xFFECEEF3),
        surface = surface,
        onSurface = Color(0xFFECEEF3),
        surfaceVariant = variant,
        onSurfaceVariant = Color(0xFFA3A9B8),
        outline = Color(0xFF3A3F4B),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
