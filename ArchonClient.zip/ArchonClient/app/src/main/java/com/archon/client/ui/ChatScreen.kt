package com.archon.client.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archon.client.chat.ChatClient
import com.archon.client.settings.AppSettings
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val hidden = ChatClient.hidden
    val visible = ChatClient.messages.filter { it.tag !in hidden }
    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    // Чат подключён, пока открыта эта вкладка
    DisposableEffect(Unit) {
        ChatClient.start()
        onDispose { ChatClient.stop() }
    }
    // К последнему сообщению: при новых сообщениях и когда открылась клавиатура
    LaunchedEffect(visible.size, imeVisible) {
        if (visible.isNotEmpty()) listState.scrollToItem(visible.size - 1)
    }

    fun send() {
        val text = input
        if (text.isBlank()) return
        input = ""
        scope.launch {
            val err = ChatClient.send(text)
            if (err != null) {
                Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
                input = text
            }
        }
    }

    Column(modifier.fillMaxSize().imePadding()) {
        // Узкая шапка: название, состояние и кнопка настроек чата
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Чат", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                val (label, color) = when (ChatClient.status) {
                    ChatClient.Status.Online -> "Онлайн · комната «${ChatClient.room}»" to Ok
                    ChatClient.Status.Connecting -> "Подключение…" to Warn
                    ChatClient.Status.Offline -> "Нет связи, переподключаюсь…" to Warn
                }
                Text(label, fontSize = 12.sp, color = color)
            }
            IconButton(onClick = { showSettings = true }) {
                Icon(Icons.Filled.Settings, contentDescription = "Ник и комната")
            }
        }

        if (visible.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "Сообщений пока нет. Напиши первым!\n\nЧат открытый: сообщения видят все в комнате. Не пиши личные данные.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp,
                )
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                state = listState,
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(visible, key = { it.id }) { m ->
                    val mine = m.tag.isNotEmpty() && m.tag == ChatClient.myTag
                    Bubble(m, mine) { ChatClient.hide(context, m.tag) }
                }
            }
        }

        // Компактное поле ввода: одна строка, растёт только когда текста много
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            ) {
                BasicTextField(
                    value = input,
                    onValueChange = { if (it.length <= 500) input = it },
                    textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Box {
                            if (input.isEmpty()) {
                                Text("Сообщение", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp)
                            }
                            inner()
                        }
                    },
                )
            }
            IconButton(onClick = { send() }, enabled = input.isNotBlank()) {
                Icon(
                    Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Отправить",
                    tint = if (input.isNotBlank()) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }

    if (showSettings) {
        var nick by remember { mutableStateOf(ChatClient.nick) }
        var room by remember { mutableStateOf(ChatClient.room) }
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Ник и комната") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = nick,
                        onValueChange = { nick = it.take(20) },
                        label = { Text("Ник") },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = room,
                        onValueChange = { room = it.take(40) },
                        label = { Text("Комната (латиница, цифры, - и _)") },
                        singleLine = true,
                    )
                    Text(
                        "В одной комнате общаются все, кто ввёл такое же название. Для закрытого чата с друзьями придумай необычное.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (hidden.isNotEmpty()) {
                        TextButton(onClick = { ChatClient.unhideAll(context) }) {
                            Text("Показать скрытых игроков (${hidden.size})")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    ChatClient.updateProfile(context, nick, room)
                    showSettings = false
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun Bubble(m: ChatClient.Message, mine: Boolean, onHide: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val time = remember(m.time) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.time * 1000)) }
    val nickColor = remember(m.tag, m.nick) {
        val accents = AppSettings.accents
        accents[Math.floorMod((m.tag.ifBlank { m.nick }).hashCode(), accents.size)].second
    }

    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = if (mine) Alignment.End else Alignment.Start,
    ) {
        Box {
            Column(
                Modifier
                    .widthIn(max = 290.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    )
                    .clickable(enabled = !mine) { menu = true }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            ) {
                if (!mine) {
                    Text(m.nick, color = nickColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Text(m.text)
                Text(time, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Скрыть этого игрока") }, onClick = { menu = false; onHide() })
            }
        }
    }
}
