package com.archon.client.ui

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.archon.client.cloud.Account
import com.archon.client.cloud.CloudMod
import com.archon.client.cloud.ImageUtil
import com.archon.client.cloud.PlayerProfile
import com.archon.client.cloud.Supa
import com.archon.client.mods.ModKind
import com.archon.client.mods.ModMeta
import com.archon.client.mods.ModsRepository
import com.archon.client.mods.PackValidator
import com.archon.client.settings.AppSettings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

internal sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    data class Error(val message: String) : Load<Nothing>
    data class Ready<out T>(val value: T) : Load<T>
}

internal fun accentOf(index: Int): Color =
    AppSettings.accents.getOrNull(index)?.second ?: AppSettings.accents[0].second

// ---------- общие маленькие элементы ----------

@Composable
internal fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 7.dp),
    ) {
        Text(
            text,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
internal fun SearchBar(value: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 16.dp, vertical = 10.dp),
    ) {
        BasicTextField(
            value = value,
            onValueChange = { if (it.length <= 40) onChange(it) },
            singleLine = true,
            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 15.sp),
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) {
                        Text(hint, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp)
                    }
                    inner()
                }
            },
        )
    }
}

/** Круглая аватарка. model: адрес или Uri картинки, либо null, тогда рисуется буква ника. */
@Composable
internal fun AvatarView(
    model: Any?,
    letter: String,
    accent: Color,
    frame: Int,
    size: Dp,
    modifier: Modifier = Modifier,
    cutout: Dp = 0.dp,
) {
    val f = FRAMES.getOrNull(frame)
    val ring = if (f != null && f.colors.size > 1) {
        Modifier.border(if (size >= 64.dp) 4.dp else 3.dp, Brush.sweepGradient(f.colors), CircleShape)
    } else {
        Modifier
    }
    // Фон аватарки непрозрачный: раньше он был полупрозрачным, и сквозь него просвечивал баннер
    // (верхняя половина круга была одного цвета, нижняя другого).
    val fill = accent.copy(alpha = 0.3f).compositeOver(MaterialTheme.colorScheme.surface)
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.background)
            .padding(cutout),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(fill),
            contentAlignment = Alignment.Center,
        ) {
            if (model != null) {
                AsyncImage(
                    model = model,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Text(
                    letter,
                    color = accent,
                    fontWeight = FontWeight.Bold,
                    fontSize = ((size - cutout * 2).value / 2.4f).sp,
                )
            }
            // рамку рисуем поверх картинки, чтобы фото её не перекрывало
            Box(Modifier.fillMaxSize().then(ring))
        }
    }
}

@Composable
internal fun UserAvatar(p: PlayerProfile, size: Dp, modifier: Modifier = Modifier, cutout: Dp = 0.dp) {
    val avatar = p.avatarPath?.takeIf { it.isNotBlank() }
    AvatarView(
        model = avatar?.let { Supa.publicUrl("images", it) },
        letter = p.username.firstOrNull()?.uppercase() ?: "?",
        accent = accentOf(p.accent),
        frame = p.frame,
        size = size,
        modifier = modifier,
        cutout = cutout,
    )
}

@Composable
internal fun ProfileHeader(p: PlayerProfile, overlay: @Composable BoxScope.() -> Unit = {}) {
    val accent = accentOf(p.accent)
    val banner = p.bannerPath?.takeIf { it.isNotBlank() }
    val bg = MaterialTheme.colorScheme.background
    Column {
        Box(Modifier.fillMaxWidth().height(196.dp)) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.6f), accent.copy(alpha = 0.2f)))),
            ) {
                if (banner != null) {
                    AsyncImage(
                        model = Supa.publicUrl("images", banner),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                // плавный переход баннера в фон
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to bg.copy(alpha = 0.85f))),
                )
                overlay()
            }
            UserAvatar(p, 100.dp, Modifier.align(Alignment.BottomStart).padding(start = 16.dp), cutout = 5.dp)
        }
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    p.username,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
            }
            if (p.status.isNotBlank()) {
                Text(p.status, color = accent, fontSize = 14.sp, modifier = Modifier.padding(top = 2.dp))
            }
            if (p.bio.isNotBlank()) {
                Text(p.bio, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

/** Круглая полупрозрачная кнопка поверх баннера, чтобы иконку было видно на любой картинке. */
@Composable
internal fun BannerIconButton(icon: ImageVector, description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .padding(8.dp)
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.45f)),
    ) {
        Icon(icon, contentDescription = description, tint = Color.White)
    }
}

/** Плашки со статистикой под профилем: сколько модов и сколько раз их скачали. */
@Composable
internal fun ProfileStats(state: Load<List<CloudMod>>, modifier: Modifier = Modifier) {
    val mods = (state as? Load.Ready)?.value
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatBox(mods?.size?.toString() ?: "—", "модов", Modifier.weight(1f))
        StatBox(mods?.sumOf { it.downloads }?.toString() ?: "—", "скачиваний", Modifier.weight(1f))
    }
}

@Composable
private fun StatBox(value: String, label: String, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------- загрузка списков ----------

@Composable
internal fun rememberMods(
    kind: String?,
    term: String,
    ownerId: String?,
    reload: Int,
    popular: Boolean = false,
): MutableState<Load<List<CloudMod>>> {
    val holder = remember { mutableStateOf<Load<List<CloudMod>>>(Load.Loading) }
    LaunchedEffect(kind, term, ownerId, reload, popular) {
        holder.value = Load.Loading
        if (term.isNotBlank()) delay(400)
        holder.value = withContext(Dispatchers.IO) {
            try {
                Load.Ready(
                    Supa.listMods(kind, term, ownerId, popular, hideReported = ownerId == null || ownerId != Account.session?.userId)
                )
            } catch (e: Exception) {
                Load.Error(Account.friendly(e))
            }
        }
    }
    return holder
}

internal fun modsSummary(state: Load<List<CloudMod>>): String = when (state) {
    is Load.Ready ->
        if (state.value.isEmpty()) "" else "Модов: ${state.value.size} · скачали ${state.value.sumOf { it.downloads }} раз"
    else -> ""
}

internal class Downloader(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onDone: () -> Unit,
) {
    val busy = mutableStateListOf<String>()

    fun download(mod: CloudMod) {
        if (mod.id in busy) return
        busy.add(mod.id)
        scope.launch {
            val err: String? = try {
                withContext(Dispatchers.IO) { Supa.download(context, mod) }
                // скачивание засчитывается один раз на аккаунт, без входа не считается
                if (Account.session != null) {
                    runCatching { Account.authed(context) { token -> Supa.countDownload(token, mod.id) } }
                }
                null
            } catch (e: Exception) {
                Account.friendly(e)
            }
            busy.remove(mod.id)
            val msg = if (err == null) "Скачано: ${mod.title}" else "«${mod.title}»: $err"
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            onDone()
        }
    }
}

@Composable
internal fun rememberDownloader(onDone: () -> Unit): Downloader {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    return remember { Downloader(context, scope, onDone) }
}

@Composable
internal fun rememberModReporter(): (CloudMod, String) -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    return remember {
        { mod: CloudMod, reason: String ->
            scope.launch {
                val uid = Account.session?.userId
                if (uid == null) {
                    Toast.makeText(context, "Войди в аккаунт, чтобы пожаловаться", Toast.LENGTH_SHORT).show()
                } else {
                    val msg = try {
                        Account.authed(context) { token -> Supa.reportMod(token, mod.id, uid, reason) }
                        "Жалоба отправлена, спасибо"
                    } catch (e: Supa.ApiException) {
                        if (e.code == 409) "Ты уже жаловался на этот мод" else Account.friendly(e)
                    } catch (e: Exception) {
                        Account.friendly(e)
                    }
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}

@Composable
internal fun rememberModDeleter(onDone: () -> Unit): (CloudMod) -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    return remember {
        { mod ->
            scope.launch {
                try {
                    Account.authed(context) { token -> Supa.deleteMod(token, mod) }
                    onDone()
                } catch (e: Exception) {
                    Toast.makeText(context, Account.friendly(e), Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}

internal fun LazyListScope.cloudModItems(
    state: Load<List<CloudMod>>,
    have: Set<String>,
    downloader: Downloader,
    myId: String?,
    onDelete: (CloudMod) -> Unit,
    onOpenOwner: ((CloudMod) -> Unit)?,
    horizontalPadding: Dp = 0.dp,
    onReport: ((CloudMod, String) -> Unit)? = null,
) {
    when (state) {
        Load.Loading -> item {
            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        is Load.Error -> item {
            Text(
                state.message,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(24.dp),
            )
        }
        is Load.Ready -> {
            if (state.value.isEmpty()) {
                item {
                    Text(
                        "Здесь пока ничего нет",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth().padding(24.dp),
                    )
                }
            } else {
                items(state.value, key = { it.id }) { mod ->
                    Box(Modifier.padding(horizontal = horizontalPadding)) {
                        CloudModCard(
                            mod = mod,
                            inLibrary = "id:${mod.id}" in have || "file:${File(mod.fileName).name}" in have,
                            busy = mod.id in downloader.busy,
                            mine = myId != null && mod.ownerId == myId,
                            onDownload = { downloader.download(mod) },
                            onDelete = { onDelete(mod) },
                            onOpenOwner = onOpenOwner?.let { open -> { open(mod) } },
                            onReport = onReport?.let { rep -> { reason: String -> rep(mod, reason) } },
                        )
                    }
                }
            }
        }
    }
}

@Composable
internal fun CloudModCard(
    mod: CloudMod,
    inLibrary: Boolean,
    busy: Boolean,
    mine: Boolean,
    onDownload: () -> Unit,
    onDelete: () -> Unit,
    onOpenOwner: (() -> Unit)?,
    onReport: ((String) -> Unit)? = null,
) {
    var reportDialog by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var imageFailed by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val image = mod.imagePath?.takeIf { it.isNotBlank() && !imageFailed }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column {
            if (image != null) {
                AsyncImage(
                    model = Supa.publicUrl("images", image),
                    contentDescription = mod.title,
                    contentScale = ContentScale.Crop,
                    onError = { imageFailed = true },
                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f),
                )
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(mod.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (onOpenOwner != null && mod.ownerName.isNotBlank()) {
                            Text(
                                "@${mod.ownerName}",
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 13.sp,
                                modifier = Modifier.clickable(onClick = onOpenOwner),
                            )
                        }
                        Text(
                            "${if (mod.kind == "world") "Мир" else "Аддон"} · ${formatSize(mod.size)} · скачали: ${mod.downloads}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    when {
                        mod.status == "pending" -> Chip("На проверке", Warn)
                        mod.status == "rejected" -> Chip("Отклонён", Color(0xFFEF4444))
                        inLibrary -> Chip("Скачано", Ok)
                        busy -> CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                        else -> Button(onClick = onDownload, shape = RoundedCornerShape(12.dp)) { Text("Скачать") }
                    }
                }
                if (mod.description.isNotBlank()) {
                    Text(
                        mod.description,
                        fontSize = 13.sp,
                        maxLines = if (expanded) Int.MAX_VALUE else 3,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.clickable { expanded = !expanded },
                    )
                }
                if (mine && mod.status == "rejected" && mod.scanNote.isNotBlank()) {
                    Text("Сервер не пропустил файл: ${mod.scanNote}", color = Color(0xFFEF4444), fontSize = 12.sp)
                }
                if (mine && mod.status == "pending") {
                    Text("Файл проверяется сервером. Пока проверка не пройдена, мод видишь только ты.", color = Warn, fontSize = 12.sp)
                }
                if (mine) {
                    TextButton(onClick = { confirm = true }) { Text("Удалить из облака") }
                } else if (onReport != null) {
                    TextButton(onClick = { reportDialog = true }) {
                        Text("Пожаловаться", color = Warn, fontSize = 13.sp)
                    }
                }
            }
        }
    }

    if (reportDialog) {
        val reasons = listOf("Вирус или вредный файл", "Неприличный контент", "Спам или обман", "Другое")
        AlertDialog(
            onDismissRequest = { reportDialog = false },
            title = { Text("Пожаловаться на мод") },
            text = {
                Column {
                    reasons.forEach { r ->
                        TextButton(
                            onClick = { reportDialog = false; onReport?.invoke(r) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(r, modifier = Modifier.fillMaxWidth()) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { reportDialog = false }) { Text("Отмена") } },
        )
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Удалить из облака?") },
            text = { Text("«${mod.title}» пропадёт для всех игроков.") },
            confirmButton = { TextButton(onClick = { confirm = false; onDelete() }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Отмена") } },
        )
    }
}

// ---------- вкладка «Моды» ----------

@Composable
fun StoreScreen(modifier: Modifier = Modifier, onNeedLogin: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var section by remember { mutableIntStateOf(0) }
    var openPlayer by remember { mutableStateOf<PlayerProfile?>(null) }
    var uploading by remember { mutableStateOf(false) }

    BackHandler(enabled = openPlayer != null || uploading) {
        if (uploading) uploading = false else openPlayer = null
    }

    val player = openPlayer
    when {
        uploading -> UploadScreen(modifier) { uploading = false }
        player != null -> PlayerScreen(modifier, player) { openPlayer = null }
        else -> Column(modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Pill("Моды", section == 0) { section = 0 }
                Pill("Игроки", section == 1) { section = 1 }
                Spacer(Modifier.weight(1f))
                if (section == 0) {
                    Button(
                        onClick = {
                            if (Account.session != null && Account.profile != null) {
                                uploading = true
                            } else {
                                Toast.makeText(context, "Сначала войди и создай профиль", Toast.LENGTH_SHORT).show()
                                onNeedLogin()
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                    ) { Text("+ Загрузить") }
                }
            }
            val openOwner: (CloudMod) -> Unit = { mod ->
                scope.launch {
                    val p = withContext(Dispatchers.IO) { runCatching { Supa.getProfile(mod.ownerId) }.getOrNull() }
                    openPlayer = p ?: PlayerProfile(mod.ownerId, mod.ownerName)
                }
            }
            if (section == 0) ModsFeed(Modifier.weight(1f), openOwner) else PlayersList(Modifier.weight(1f)) { openPlayer = it }
        }
    }
}

@Composable
private fun ModsFeed(modifier: Modifier, onOpenOwner: (CloudMod) -> Unit) {
    val context = LocalContext.current
    var kind by remember { mutableStateOf<String?>(null) }
    var popular by remember { mutableStateOf(false) }
    var term by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val state by rememberMods(kind, term, null, reload, popular)
    val have = remember(refresh) { ModMeta.libraryKeys(context) }
    val downloader = rememberDownloader { refresh++ }
    val deleter = rememberModDeleter { reload++ }
    val reporter = rememberModReporter()

    Column(modifier.fillMaxSize()) {
        SearchBar(term, { term = it }, "Поиск модов", Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Pill("Все", kind == null) { kind = null }
            Pill("Аддоны", kind == "addon") { kind = "addon" }
            Pill("Миры", kind == "world") { kind = "world" }
            Spacer(Modifier.width(6.dp))
            Pill("Новые", !popular) { popular = false }
            Pill("Популярные", popular) { popular = true }
            TextButton(onClick = { reload++ }) { Text("Обновить") }
        }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            cloudModItems(state, have, downloader, Account.session?.userId, deleter, onOpenOwner, onReport = reporter)
        }
    }
}

@Composable
private fun PlayersList(modifier: Modifier, onOpen: (PlayerProfile) -> Unit) {
    var term by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }
    val holder = remember { mutableStateOf<Load<List<PlayerProfile>>>(Load.Loading) }

    LaunchedEffect(term, reload) {
        holder.value = Load.Loading
        if (term.isNotBlank()) delay(400)
        holder.value = withContext(Dispatchers.IO) {
            try {
                Load.Ready(Supa.searchPlayers(term))
            } catch (e: Exception) {
                Load.Error(Account.friendly(e))
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        SearchBar(term, { term = it }, "Найти игрока по нику", Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            when (val s = holder.value) {
                Load.Loading -> item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is Load.Error -> item {
                    Column(Modifier.fillMaxWidth().padding(24.dp)) {
                        Text(s.message, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { reload++ }) { Text("Повторить") }
                    }
                }
                is Load.Ready -> {
                    if (s.value.isEmpty()) {
                        item {
                            Text(
                                "Игроков не найдено",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.fillMaxWidth().padding(24.dp),
                            )
                        }
                    } else {
                        items(s.value, key = { it.id }) { p -> PlayerRow(p) { onOpen(p) } }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayerRow(p: PlayerProfile, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Card(
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().clip(shape).clickable(onClick = onClick),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            UserAvatar(p, 48.dp)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        p.username,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                }
                val sub = p.status.ifBlank { p.bio }
                if (sub.isNotBlank()) {
                    Text(
                        sub,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun PlayerScreen(modifier: Modifier, p: PlayerProfile, onBack: () -> Unit) {
    val context = LocalContext.current
    var reload by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val state by rememberMods(null, "", p.id, reload)
    val have = remember(refresh) { ModMeta.libraryKeys(context) }
    val downloader = rememberDownloader { refresh++ }
    val deleter = rememberModDeleter { reload++ }
    val reporter = rememberModReporter()

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            ProfileHeader(p) {
                BannerIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Назад", onBack, Modifier.align(Alignment.TopStart))
            }
        }
        item { ProfileStats(state, Modifier.padding(horizontal = 20.dp)) }
        item {
            Text("Моды игрока", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        }
        cloudModItems(
            state, have, downloader, Account.session?.userId, deleter, null, horizontalPadding = 20.dp, onReport = reporter,
        )
    }
}

// ---------- загрузка мода в облако ----------

@Composable
private fun UploadScreen(modifier: Modifier, onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val files = remember { ModsRepository.listAll(context) }
    var selected by remember { mutableStateOf<File?>(null) }
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var working by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) imageUri = uri
    }

    fun upload() {
        val file = selected ?: return
        val me = Account.profile
        if (me == null) {
            error = "Сначала создай профиль"
            return
        }
        if (file.length() > Supa.MAX_FILE_BYTES) {
            error = "Файл больше 50 МБ, бесплатный сервер его не примет"
            return
        }
        working = true
        error = null
        scope.launch {
            try {
                val problem = withContext(Dispatchers.IO) { PackValidator.check(file, strict = true) }
                if (problem != null) {
                    error = problem
                    return@launch
                }
                val ts = System.currentTimeMillis()
                val path = "${me.id}/${ts}_${Supa.safeName(file.name)}"
                val kind = if (ModKind.Worlds.accepts(file.name)) "world" else "addon"
                val bytes = imageUri?.let { uri ->
                    withContext(Dispatchers.IO) { ImageUtil.compress(context, uri, 1280) }
                }
                var imgPath: String? = null
                var modId: String? = null
                // Каждый запрос отдельно: если вход устареет посередине, повторится только он,
                // а не вся загрузка (раньше повтор падал с ошибкой «уже занят»)
                try {
                    Account.authed(context) { token -> Supa.uploadFile(token, Supa.UPLOAD_BUCKET, path, file) }
                    if (bytes != null) {
                        val p = "${me.id}/${ts}_preview.jpg"
                        Account.authed(context) { token -> Supa.uploadBytes(token, "images", p, bytes) }
                        imgPath = p
                    }
                    val img = imgPath
                    modId = Account.authed(context) { token ->
                        Supa.insertMod(token, me.id, title.trim(), desc.trim(), kind, path, file.name, file.length(), img)
                    }
                } catch (e: Exception) {
                    // мод не создан — убираем уже загруженные файлы, чтобы не висели в облаке
                    if (modId == null) {
                        runCatching { Account.authed(context) { token -> Supa.deleteUpload(token, path) } }
                        imgPath?.let { p -> runCatching { Account.authed(context) { token -> Supa.deleteImage(token, p) } } }
                    }
                    throw e
                }
                val id = modId!!
                // сервер сам проверяет файл; если проверка недоступна, мод просто останется «на проверке»
                val scan = runCatching { Account.authed(context) { token -> Supa.scanMod(token, id) } }.getOrNull()
                if (scan != null && scan.status == "rejected") {
                    error = "Сервер не пропустил файл: ${scan.reason}"
                    return@launch
                }
                val msg = if (scan == null || scan.status == "pending") {
                    "Загружено. Мод появится у всех после проверки сервером"
                } else {
                    "Загружено и проверено"
                }
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                onClose()
            } catch (e: Exception) {
                error = Account.friendly(e)
            } finally {
                working = false
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose, enabled = !working) { Text("Отмена") }
            Spacer(Modifier.weight(1f))
            Text("Загрузка в облако", fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.width(64.dp))
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Text("1. Выбери файл из своей библиотеки", fontWeight = FontWeight.Medium)
            if (files.isEmpty()) {
                Text(
                    "Библиотека пуста. Сначала добавь файл на вкладке «Файлы».",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp,
                )
            }
            files.forEach { f ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            selected = f
                            if (title.isBlank()) title = f.nameWithoutExtension
                        },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = selected == f, onClick = {
                        selected = f
                        if (title.isBlank()) title = f.nameWithoutExtension
                    })
                    Column {
                        Text(f.nameWithoutExtension, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${typeLabel(f.name)} · ${formatSize(f.length())}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Text("2. Название и описание", fontWeight = FontWeight.Medium)
            OutlinedTextField(
                value = title,
                onValueChange = { title = it.take(80) },
                label = { Text("Название") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = desc,
                onValueChange = { desc = it.take(600) },
                label = { Text("Описание (необязательно)") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth(),
            )

            Text(
                "Перед загрузкой файл проверяется: программы (APK, EXE и т.п.) внутри мода не допускаются.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text("3. Картинка (необязательно)", fontWeight = FontWeight.Medium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { pickImage.launch("image/*") }, shape = RoundedCornerShape(12.dp)) {
                    Text(if (imageUri == null) "Выбрать картинку" else "Заменить")
                }
                if (imageUri != null) {
                    AsyncImage(
                        model = imageUri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.padding(start = 12.dp).size(56.dp).clip(RoundedCornerShape(10.dp)),
                    )
                }
            }

            error?.let { Text(it, color = Warn, fontSize = 13.sp) }
            Button(
                onClick = { upload() },
                enabled = selected != null && title.isNotBlank() && !working,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (working) "Загрузка…" else "Загрузить", fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(16.dp))
        }
    }
}
