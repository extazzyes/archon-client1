package com.archon.client.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archon.client.minecraft.McStatus
import com.archon.client.mods.ModKind
import com.archon.client.mods.ModsRepository

@Composable
fun HomeScreen(
    status: McStatus,
    onPlay: () -> Unit,
    onInstall: () -> Unit,
    onOpenAddons: () -> Unit,
    onOpenWorlds: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val addons = remember { ModsRepository.list(context, ModKind.Addons).size }
    val worlds = remember { ModsRepository.list(context, ModKind.Worlds).size }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Hero(onOpenSettings)
        Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            MinecraftCard(status, onPlay, onInstall)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickCard("Аддоны", "$addons в библиотеке", onOpenAddons, Modifier.weight(1f))
                QuickCard("Миры", "$worlds в библиотеке", onOpenWorlds, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun Hero(onSettings: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Box(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(primary.copy(alpha = 0.45f), MaterialTheme.colorScheme.background)))
            .padding(start = 24.dp, end = 24.dp, top = 40.dp, bottom = 28.dp),
    ) {
        Column {
            Text("ARCHON", fontSize = 40.sp, fontWeight = FontWeight.Black, letterSpacing = 6.sp, color = Color.White)
            Text("CLIENT", fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 12.sp, color = primary)
        }
        IconButton(onClick = onSettings, modifier = Modifier.align(Alignment.TopEnd)) {
            Icon(Icons.Filled.Settings, contentDescription = "Настройки")
        }
    }
}

@Composable
private fun MinecraftCard(status: McStatus, onPlay: () -> Unit, onInstall: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Minecraft Bedrock", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        when (status) {
                            McStatus.NotInstalled -> "Игра не найдена на устройстве"
                            is McStatus.Installed -> "Версия ${status.versionName}"
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp,
                    )
                }
                when (status) {
                    McStatus.NotInstalled -> Badge("Не установлена", Warn)
                    is McStatus.Installed -> Badge("Установлена", Ok)
                }
            }
            when (status) {
                McStatus.NotInstalled -> PlayButton("УСТАНОВИТЬ", showIcon = false, onClick = onInstall)
                is McStatus.Installed -> PlayButton("ИГРАТЬ", showIcon = true, onClick = onPlay)
            }
        }
    }
}

@Composable
private fun QuickCard(title: String, subtitle: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Card(
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier.clip(shape).clickable(onClick = onClick),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun Badge(text: String, color: Color) {
    Box(
        Modifier
            .background(color.copy(alpha = 0.15f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun PlayButton(text: String, showIcon: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().height(56.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (showIcon) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
            }
            Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
    }
}
