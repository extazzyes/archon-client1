package com.archon.client.backup

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.RemoteException
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.archon.client.settings.AppSettings
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.io.IOException

/**
 * Вся логика резервных копий миров: состояние Shizuku, связь со службой, автокопии.
 * Состояние хранится в Compose-переменных, экран обновляется сам.
 */
object BackupManager {
    enum class Setup { NotInstalled, NotRunning, NoPermission, Ready }

    data class WorldInfo(val folder: String, val name: String, val size: Long, val modified: Long) {
        /** Тот же идентификатор, что в имени файла копии (шестнадцатеричное имя папки). */
        val id: String get() = folder.toByteArray(Charsets.UTF_8).joinToString("") { "%02x".format(it) }
    }

    data class BackupInfo(val file: String, val world: String, val id: String, val size: Long, val time: Long)

    const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
    private const val PERMISSION_REQUEST = 7421
    private const val SERVICE_VERSION = 4
    private const val AUTO_THROTTLE_MS = 5 * 60_000L

    var setup by mutableStateOf(Setup.NotInstalled)
        private set
    var wantEnable by mutableStateOf(false)
        private set
    var busy by mutableStateOf(false)
        private set
    var worlds by mutableStateOf<List<WorldInfo>>(emptyList())
        private set
    var backups by mutableStateOf<List<BackupInfo>>(emptyList())
        private set
    var folderProblem by mutableStateOf<String?>(null)
        private set
    var lastMessage by mutableStateOf("")
        private set
    var lastTime by mutableLongStateOf(0L)
        private set
    var worldsChecked by mutableStateOf(false)
        private set

    /** Доступ отклонён «навсегда»: включить его можно только вручную в приложении Shizuku. */
    var permissionBlocked by mutableStateOf(false)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val lock = Mutex()
    private var initialized = false
    private var service: IWorldBackupService? = null
    private var pending: CompletableDeferred<IWorldBackupService>? = null
    private var lastAutoAt = 0L
    private var foreground = false
    private var askedThisActivation = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val remote = if (binder != null && binder.pingBinder()) IWorldBackupService.Stub.asInterface(binder) else null
            service = remote
            if (remote != null) {
                pending?.complete(remote)
            } else {
                pending?.completeExceptionally(IOException("Не удалось подключиться к Shizuku"))
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
        }
    }

    // ---------- состояние Shizuku ----------
    fun init(context: Context) {
        if (initialized) return
        initialized = true
        val app = context.applicationContext
        try {
            Shizuku.addBinderReceivedListenerSticky { refreshSetup(app) }
            Shizuku.addBinderDeadListener {
                service = null
                refreshSetup(app)
            }
            Shizuku.addRequestPermissionResultListener { _, _ -> refreshSetup(app) }
        } catch (_: Throwable) {
            // без Shizuku приложение работает как раньше
        }
        refreshSetup(app)
    }

    @Suppress("DEPRECATION")
    private fun isInstalled(context: Context): Boolean = try {
        context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    }

    private fun running(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    private fun permissionGranted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    fun refreshSetup(context: Context) {
        val app = context.applicationContext
        setup = when {
            running() -> if (permissionGranted()) Setup.Ready else Setup.NoPermission
            isInstalled(app) -> Setup.NotRunning
            else -> Setup.NotInstalled
        }
        if (setup == Setup.Ready) permissionBlocked = false
        if (!wantEnable) return
        when (setup) {
            // Shizuku готов: завершаем включение и сразу делаем первую копию
            Setup.Ready -> {
                wantEnable = false
                AppSettings.setWorldBackupEnabled(app, true)
                startFirstRun(app)
            }
            // Shizuku работает, но доступа у Archon ещё нет: сами показываем системное окно запроса
            Setup.NoPermission -> askPermissionOnce()
            else -> Unit
        }
    }

    private fun askPermissionOnce() {
        // Окно запроса можно показать только когда Archon на экране; спрашиваем один раз за включение
        if (askedThisActivation || !foreground) return
        askedThisActivation = true
        requestPermission()
    }

    private fun startFirstRun(app: Context) {
        scope.launch { autoBackup(app, ignoreThrottle = true) }
    }

    /** Открыть приложение Shizuku. false, если его нет или оно не открылось. */
    fun openShizuku(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    /** true, если системное окно запроса показано. false: доступ отклонён навсегда, нужно включить вручную в Shizuku. */
    fun requestPermission(): Boolean = try {
        if (Shizuku.shouldShowRequestPermissionRationale()) {
            permissionBlocked = true
            false
        } else {
            Shizuku.requestPermission(PERMISSION_REQUEST)
            true
        }
    } catch (_: Throwable) {
        false
    }

    // ---------- тумблер ----------
    fun setEnabled(context: Context, on: Boolean) {
        val app = context.applicationContext
        askedThisActivation = false
        permissionBlocked = false
        if (!on) {
            wantEnable = false
            AppSettings.setWorldBackupEnabled(app, false)
            disconnect(app)
            return
        }
        foreground = true // тумблер нажат на экране, значит Archon сейчас на виду
        wantEnable = true
        // Shizuku готов: включится сразу. Нет доступа: появится окно запроса. Остальное покажет инструкция.
        refreshSetup(app)
        // Shizuku установлен, но не запущен: открываем его, чтобы пользователь сразу запустил
        if (wantEnable && setup == Setup.NotRunning) openShizuku(app)
    }

    private fun userServiceArgs(context: Context) =
        Shizuku.UserServiceArgs(ComponentName(context, WorldBackupUserService::class.java))
            .daemon(false)
            .processNameSuffix("world-backup")
            .version(SERVICE_VERSION)

    private fun disconnect(context: Context) {
        runCatching { Shizuku.unbindUserService(userServiceArgs(context), connection, true) }
        service = null
    }

    // ---------- связь со службой ----------
    private suspend fun connect(context: Context): IWorldBackupService {
        service?.let { if (it.asBinder().pingBinder()) return it }
        val deferred = CompletableDeferred<IWorldBackupService>()
        pending = deferred
        Shizuku.bindUserService(userServiceArgs(context), connection)
        return try {
            withTimeout(10_000) { deferred.await() }
        } catch (_: TimeoutCancellationException) {
            throw IOException("Shizuku не ответил. Проверь, что он запущен.")
        }
    }

    private suspend fun <T> remote(context: Context, block: (IWorldBackupService) -> T): T {
        return try {
            val s = connect(context)
            withContext(Dispatchers.IO) { block(s) }
        } catch (_: RemoteException) {
            service = null
            val s = connect(context)
            withContext(Dispatchers.IO) { block(s) }
        }
    }

    // ---------- загрузка списков ----------
    private suspend fun loadAll(context: Context) {
        val w = JSONObject(remote(context) { it.listWorlds() })
        if (w.optBoolean("ok")) {
            worlds = parseWorlds(w.optJSONArray("worlds"))
            folderProblem = null
        } else {
            worlds = emptyList()
            folderProblem = w.optString("message").ifBlank { "Не удалось прочитать миры" }
        }
        worldsChecked = true
        val b = JSONObject(remote(context) { it.listBackups() })
        backups = if (b.optBoolean("ok")) parseBackups(b.optJSONArray("backups")) else emptyList()
    }

    private fun parseWorlds(a: JSONArray?): List<WorldInfo> {
        if (a == null) return emptyList()
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            WorldInfo(o.getString("folder"), o.optString("name"), o.optLong("size"), o.optLong("modified"))
        }
    }

    private fun parseBackups(a: JSONArray?): List<BackupInfo> {
        if (a == null) return emptyList()
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            BackupInfo(o.getString("file"), o.optString("world"), o.optString("id"), o.optLong("size"), o.optLong("time"))
        }
    }

    // ---------- операции ----------
    private fun launchOp(block: suspend () -> Unit) {
        scope.launch {
            lock.withLock {
                busy = true
                try {
                    block()
                } catch (e: Exception) {
                    lastMessage = friendly(e)
                } finally {
                    busy = false
                }
            }
        }
    }

    private fun friendly(e: Exception): String = when (e) {
        is IOException -> e.message ?: "Ошибка Shizuku"
        is SecurityException -> "Нет доступа через Shizuku. Проверь разрешение для Archon Client."
        else -> e.message ?: e.javaClass.simpleName
    }

    /** Обновить состояние и списки (если Shizuku готов). */
    fun refresh(context: Context) {
        val app = context.applicationContext
        refreshSetup(app)
        if (setup != Setup.Ready) return
        launchOp { loadAll(app) }
    }

    fun backupAll(context: Context, force: Boolean) {
        val app = context.applicationContext
        launchOp { lastMessage = backupWorlds(app, null, force) }
    }

    fun backupOne(context: Context, folder: String, force: Boolean) {
        val app = context.applicationContext
        launchOp { lastMessage = backupWorlds(app, folder, force) }
    }

    fun restore(context: Context, file: String) {
        val app = context.applicationContext
        launchOp {
            val r = JSONObject(remote(app) { it.restoreBackup(file) })
            lastMessage = if (r.optBoolean("ok")) {
                "Мир восстановлен как новый. Полностью закрой Minecraft и открой заново: мир появится в списке."
            } else {
                r.optString("message").ifBlank { "Не удалось восстановить мир" }
            }
            lastTime = System.currentTimeMillis()
            loadAll(app)
        }
    }

    fun delete(context: Context, file: String) {
        val app = context.applicationContext
        launchOp {
            val r = JSONObject(remote(app) { it.deleteBackup(file) })
            lastMessage = if (r.optBoolean("ok")) "Копия удалена" else r.optString("message").ifBlank { "Не удалось удалить копию" }
            loadAll(app)
        }
    }

    private suspend fun backupWorlds(context: Context, only: String?, force: Boolean): String {
        loadAll(context)
        val list = if (only == null) worlds else worlds.filter { it.folder == only }
        if (list.isEmpty()) return folderProblem ?: "Миры не найдены"
        val keep = AppSettings.backupKeep
        var made = 0
        var unchanged = 0
        var playing = 0
        val errors = mutableListOf<String>()
        for (w in list) {
            val r = JSONObject(remote(context) { it.backupWorld(w.folder, keep, force) })
            when {
                !r.optBoolean("ok") -> errors += "${w.name}: ${r.optString("message")}"
                r.optString("skipped") == "busy" -> playing++
                r.has("skipped") -> unchanged++
                else -> made++
            }
        }
        loadAll(context)
        lastTime = System.currentTimeMillis()
        val parts = mutableListOf("создано копий: $made")
        if (unchanged > 0) parts += "без изменений: $unchanged"
        if (playing > 0) parts += "сейчас в игре: $playing (скопирую позже)"
        if (errors.isNotEmpty()) parts += "ошибки: " + errors.joinToString("; ")
        return parts.joinToString(", ").replaceFirstChar { it.uppercase() }
    }

    // ---------- автоматика ----------
    /** Вызывается при открытии приложения и перед запуском Minecraft. Копирует только изменившиеся миры. */
    suspend fun autoBackup(context: Context, ignoreThrottle: Boolean) {
        if (!AppSettings.worldBackupEnabled) return
        val app = context.applicationContext
        refreshSetup(app)
        if (setup != Setup.Ready) return
        val now = System.currentTimeMillis()
        if (!ignoreThrottle && now - lastAutoAt < AUTO_THROTTLE_MS) return
        if (!lock.tryLock()) return
        try {
            busy = true
            lastAutoAt = now
            lastMessage = backupWorlds(app, null, false)
        } catch (e: Exception) {
            lastMessage = friendly(e)
        } finally {
            busy = false
            lock.unlock()
        }
    }

    fun onResume(context: Context) {
        val app = context.applicationContext
        init(app)
        foreground = true
        refreshSetup(app)
        if (AppSettings.worldBackupEnabled && setup == Setup.Ready) {
            scope.launch { autoBackup(app, ignoreThrottle = false) }
        }
    }

    fun onPause() {
        foreground = false
    }
}
