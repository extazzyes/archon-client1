package com.archon.client.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.archon.client.cloud.Account
import com.archon.client.cloud.ImageUtil
import com.archon.client.cloud.PlayerProfile
import com.archon.client.cloud.Supa
import com.archon.client.mods.ModsRepository
import com.archon.client.settings.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ProfileScreen(modifier: Modifier = Modifier, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val session = Account.session
    val profile = Account.profile
    var editing by remember { mutableStateOf(false) }

    BackHandler(enabled = editing && profile != null) { editing = false }

    LaunchedEffect(session?.userId) {
        if (session != null && Account.profile == null) Account.refreshProfile()
    }

    when {
        session == null -> AuthForm(modifier, onOpenSettings)
        profile == null && Account.profileError != null -> Column(
            modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Не удалось загрузить профиль", fontWeight = FontWeight.Bold)
            Text(
                Account.profileError.orEmpty(),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 8.dp),
            )
            val scope = rememberCoroutineScope()
            Button(onClick = { scope.launch { Account.refreshProfile() } }) { Text("Повторить") }
            TextButton(onClick = { Account.signOut(context) }) { Text("Выйти") }
        }
        profile == null && !Account.profileChecked -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        profile == null -> EditProfileForm(modifier, null, onDone = {}, onCancel = { Account.signOut(context) })
        editing -> EditProfileForm(modifier, profile, onDone = { editing = false }, onCancel = { editing = false })
        else -> MyProfile(modifier, profile, onEdit = { editing = true }, onOpenSettings = onOpenSettings)
    }
}

@Composable
private fun AuthForm(modifier: Modifier, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var register by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var working by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (register) "Регистрация" else "Вход",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, contentDescription = "Настройки") }
        }
        Text(
            "Аккаунт нужен, чтобы загружать свои моды и иметь профиль. Скачивать чужие моды можно и без него.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Почта") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Пароль (минимум 6 символов)") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(),
        )
        message?.let { Text(it, color = Warn, fontSize = 13.sp) }
        Button(
            onClick = {
                working = true
                message = null
                scope.launch {
                    val r = if (register) Account.signUp(context, email, password) else Account.signIn(context, email, password)
                    working = false
                    message = r
                }
            },
            enabled = email.isNotBlank() && password.length >= 6 && !working,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (working) "Подождите…" else if (register) "Создать аккаунт" else "Войти", fontWeight = FontWeight.Bold) }
        TextButton(onClick = { register = !register; message = null }) {
            Text(if (register) "Уже есть аккаунт? Войти" else "Нет аккаунта? Зарегистрироваться")
        }
    }
}

@Composable
private fun MyProfile(modifier: Modifier, me: PlayerProfile, onEdit: () -> Unit, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    var reload by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val state by rememberMods(null, "", me.id, reload)
    val have = remember(refresh) { ModsRepository.listAll(context).map { it.name }.toSet() }
    val downloader = rememberDownloader { refresh++ }
    val deleter = rememberModDeleter { reload++ }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, contentDescription = "Настройки") }
                }
                ProfileHeader(me)
            }
        }
        item {
            Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onEdit, shape = RoundedCornerShape(14.dp)) { Text("Редактировать") }
                OutlinedButton(onClick = { Account.signOut(context) }, shape = RoundedCornerShape(14.dp)) { Text("Выйти") }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text("Мои загрузки", fontWeight = FontWeight.Bold)
                val summary = modsSummary(state)
                if (summary.isNotEmpty()) {
                    Text(summary, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        cloudModItems(state, have, downloader, me.id, deleter, null)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 6.dp),
    )
}

@Composable
private fun ImageRow(what: String, hasImage: Boolean, onPick: () -> Unit, onRemove: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = onPick, shape = RoundedCornerShape(12.dp)) {
            Text(if (hasImage) "Заменить $what" else "Выбрать $what")
        }
        if (hasImage) {
            TextButton(onClick = onRemove) { Text("Убрать", color = Warn) }
        }
    }
}

/** Так профиль выглядит для других игроков. Обновляется, пока ты редактируешь. */
@Composable
private fun EditPreview(
    name: String,
    status: String,
    accent: Int,
    frame: Int,
    prefix: Int,
    avatar: Any?,
    banner: Any?,
) {
    val color = accentOf(accent)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(110.dp)
                .background(Brush.horizontalGradient(listOf(color.copy(alpha = 0.6f), color.copy(alpha = 0.2f)))),
        ) {
            if (banner != null) {
                AsyncImage(
                    model = banner,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            AvatarView(avatar, name.firstOrNull()?.uppercase() ?: "?", color, frame, 64.dp)
            Column(Modifier.padding(start = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        name.ifBlank { "Твой ник" },
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    PrefixTag(prefix)
                }
                if (status.isNotBlank()) {
                    Text(status, color = color, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun EditProfileForm(modifier: Modifier, initial: PlayerProfile?, onDone: () -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var username by remember { mutableStateOf(initial?.username ?: "") }
    var status by remember { mutableStateOf(initial?.status ?: "") }
    var bio by remember { mutableStateOf(initial?.bio ?: "") }
    var accent by remember { mutableIntStateOf(initial?.accent ?: 0) }
    var frame by remember { mutableIntStateOf(initial?.frame ?: 0) }
    var prefix by remember { mutableIntStateOf(initial?.prefix ?: 0) }
    var avatarUri by remember { mutableStateOf<Uri?>(null) }
    var bannerUri by remember { mutableStateOf<Uri?>(null) }
    var removeAvatar by remember { mutableStateOf(false) }
    var removeBanner by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val pickAvatar = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        if (it != null) {
            avatarUri = it
            removeAvatar = false
        }
    }
    val pickBanner = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        if (it != null) {
            bannerUri = it
            removeBanner = false
        }
    }

    val oldAvatarUrl = initial?.avatarPath?.takeIf { it.isNotBlank() }?.let { Supa.publicUrl("images", it) }
    val oldBannerUrl = initial?.bannerPath?.takeIf { it.isNotBlank() }?.let { Supa.publicUrl("images", it) }
    val avatarModel: Any? = avatarUri ?: if (removeAvatar) null else oldAvatarUrl
    val bannerModel: Any? = bannerUri ?: if (removeBanner) null else oldBannerUrl

    fun save() {
        val nick = username.trim()
        if (nick.length !in 3..20 || !nick.all { it.isLetterOrDigit() || it == '_' }) {
            error = "Ник: от 3 до 20 символов, только буквы, цифры и _"
            return
        }
        val uid = Account.session?.userId ?: return
        working = true
        error = null
        scope.launch {
            try {
                val ts = System.currentTimeMillis()
                val avatarBytes = avatarUri?.let { u -> withContext(Dispatchers.IO) { ImageUtil.compress(context, u, 512) } }
                val bannerBytes = bannerUri?.let { u -> withContext(Dispatchers.IO) { ImageUtil.compress(context, u, 1280) } }
                val oldAvatar = initial?.avatarPath
                val oldBanner = initial?.bannerPath
                var avatarPath: String? = if (removeAvatar) null else oldAvatar
                var bannerPath: String? = if (removeBanner) null else oldBanner
                val saved = Account.authed(context) { token ->
                    if (avatarBytes != null) {
                        val p = "$uid/avatar_$ts.jpg"
                        Supa.uploadBytes(token, "images", p, avatarBytes)
                        avatarPath = p
                    }
                    if (bannerBytes != null) {
                        val p = "$uid/banner_$ts.jpg"
                        Supa.uploadBytes(token, "images", p, bannerBytes)
                        bannerPath = p
                    }
                    val result = Supa.saveProfile(
                        token,
                        PlayerProfile(
                            id = uid,
                            username = nick,
                            bio = bio.trim(),
                            accent = accent,
                            avatarPath = avatarPath,
                            bannerPath = bannerPath,
                            frame = frame,
                            prefix = prefix,
                            status = status.trim(),
                        ),
                    )
                    // старые картинки удаляем, чтобы они не занимали место в облаке
                    if (!oldAvatar.isNullOrBlank() && oldAvatar != avatarPath) Supa.deleteImage(token, oldAvatar)
                    if (!oldBanner.isNullOrBlank() && oldBanner != bannerPath) Supa.deleteImage(token, oldBanner)
                    result
                }
                Account.updateProfile(saved)
                Toast.makeText(context, "Профиль сохранён", Toast.LENGTH_SHORT).show()
                onDone()
            } catch (e: Exception) {
                error = Account.friendly(e)
            } finally {
                working = false
            }
        }
    }

    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onCancel, enabled = !working) { Text(if (initial == null) "Выйти" else "Отмена") }
            Spacer(Modifier.weight(1f))
            Text(if (initial == null) "Создай профиль" else "Мой профиль", fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { save() }, enabled = !working && username.isNotBlank()) { Text("Сохранить") }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            EditPreview(username.trim(), status.trim(), accent, frame, prefix, avatarModel, bannerModel)

            SectionTitle("Ник и описание")
            OutlinedTextField(
                value = username,
                onValueChange = { username = it.take(20) },
                label = { Text("Ник (виден всем игрокам)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = status,
                onValueChange = { status = it.take(40) },
                label = { Text("Статус (коротко, под ником)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = bio,
                onValueChange = { bio = it.take(200) },
                label = { Text("О себе (необязательно)") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth(),
            )

            SectionTitle("Картинки")
            ImageRow(
                what = "аватарку",
                hasImage = avatarModel != null,
                onPick = { pickAvatar.launch("image/*") },
                onRemove = {
                    avatarUri = null
                    removeAvatar = true
                },
            )
            ImageRow(
                what = "баннер",
                hasImage = bannerModel != null,
                onPick = { pickBanner.launch("image/*") },
                onRemove = {
                    bannerUri = null
                    removeBanner = true
                },
            )

            SectionTitle("Цвет профиля")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AppSettings.accents.forEachIndexed { i, (_, c) ->
                    ColorDot(c, selected = i == accent) { accent = i }
                }
            }

            SectionTitle("Рамка аватарки")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FRAMES.forEachIndexed { i, f -> Pill(f.name, i == frame) { frame = i } }
            }

            SectionTitle("Префикс перед ником")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PREFIXES.forEachIndexed { i, pf -> Pill(pf.label, i == prefix) { prefix = i } }
            }

            error?.let { Text(it, color = Warn, fontSize = 13.sp) }
            if (working) CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
        }
    }
}
