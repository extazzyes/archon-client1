package com.archon.client.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Рамка вокруг аватарки. Номер рамки хранится в профиле, пустой список цветов значит «без рамки». */
internal class AvatarFrame(val name: String, val colors: List<Color>)

internal val FRAMES = listOf(
    AvatarFrame("Без рамки", emptyList()),
    AvatarFrame("Золото", listOf(Color(0xFFFFE08A), Color(0xFFC8921B), Color(0xFFFFE08A), Color(0xFFB8860B), Color(0xFFFFE08A))),
    AvatarFrame("Неон", listOf(Color(0xFF22D3EE), Color(0xFF8B5CF6), Color(0xFFEC4899), Color(0xFF22D3EE))),
    AvatarFrame("Огонь", listOf(Color(0xFFFF6B35), Color(0xFFFFC300), Color(0xFFFF2E2E), Color(0xFFFF6B35))),
    AvatarFrame(
        "Радуга",
        listOf(
            Color(0xFFEF4444), Color(0xFFF59E0B), Color(0xFF22C55E),
            Color(0xFF06B6D4), Color(0xFF3B82F6), Color(0xFFA855F7), Color(0xFFEF4444),
        ),
    ),
    AvatarFrame("Лёд", listOf(Color(0xFFE0F7FF), Color(0xFF38BDF8), Color(0xFFE0F7FF), Color(0xFF0EA5E9), Color(0xFFE0F7FF))),
    AvatarFrame("Сакура", listOf(Color(0xFFFBCFE8), Color(0xFFEC4899), Color(0xFFFBCFE8))),
    AvatarFrame("Изумруд", listOf(Color(0xFF6EE7B7), Color(0xFF059669), Color(0xFF6EE7B7), Color(0xFF047857), Color(0xFF6EE7B7))),
)
