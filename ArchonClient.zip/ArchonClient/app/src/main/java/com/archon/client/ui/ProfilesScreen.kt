package com.archon.client.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archon.client.mods.InstallQueue
import com.archon.client.mods.ModBundler
import com.archon.client.mods.ModsRepository
import com.archon.client.profiles.Profile
import com.archon.client.profiles.ProfileStore
import com.archon.client.settings.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private val EMOJIS = listOf("🎮", "⚔️", "🏰", "🌍", "🔥", "⭐", "🧪", "🐉", "🏹", "💎", "🚀", "🎯")

@Composable
fun ProfilesScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<Profile?>(null) }
    var creating by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Profile?>(null) }
    var busyId by remember { mutableStateOf<String?>(null) }
    val inEditor = creating || editing != null

    BackHandler(enabled = inEditor) {
        creating = false
        editing = null
    }

    fun install(p: Profile) {
        if (busyId != null) return
        val byName = ModsRepository.listAll(context).associateBy { it.name }
        val files = p.files.mapNotNull { byName[it] }
        if (files.isEmpty()) {
            Toast.makeText(context, "В профиле нет файлов из библиотеки", Toast.LENGTH_LONG).show()
            return
        }
        busyId = p.id
        scope.launch {
            val plan = withContext(Dispatchers.IO) { runCatching { ModBundler.plan(context, files) } }
            busyId = null
            plan.onSuccess { list ->
                val missing = p.files.size - files.size
                if (missing > 0) {
                    Toast.makeText(context, "Пропущено файлов, которых нет в библиотеке: $missing", Toast.LENGTH_LONG).show()
                }
                ProfileStore.setActive(context, p.id)
                InstallQueue.start(context, list)
            }.onFailure {
                Toast.makeText(context, "Не удалось подготовить файлы: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    if (inEditor) {
        ProfileEditor(
            initial = editing,
            modifier = modifier,
            onClose = {
                creating = false
                editing = null
            },
            onSave = {
                ProfileStore.upsert(context, it)
                creating = false
                editing = null
            },
        )
    } else {
        Column(modifier.fillMaxSize()) {
            Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 8.dp)) {
                Text("Профили", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(
                    "Набор аддонов и миров, который ставится в Minecraft одной кнопкой",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            QueueBanner()
            Row(Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                Button(onClick = { creating = true }, shape = RoundedCornerShape(14.dp)) { Text("+ Новый профиль") }
            }
            if (ProfileStore.profiles.isEmpty()) {
                Column(
                    Modifier.weight(1f).fillMaxWidth().padding(32.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Профилей пока нет", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Например, «Выживание» с одними аддонами и «Творчество» с другими. Сначала добавь файлы на вкладках «Аддоны» и «Миры».",
                        modifier = Modifier.padding(top = 8.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                }
            } else {
                LazyColumn(
                    Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(ProfileStore.profiles, key = { it.id }) { p ->
                        ProfileCard(
                            p = p,
                            active = p.id == ProfileStore.activeId,
                            busy = busyId == p.id,
                            onInstall = { install(p) },
                            onEdit = { editing = p },
                            onDelete = { toDelete = p },
                        )
                    }
                }
            }
        }
    }

    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Удалить профиль?") },
            text = { Text("«${p.name}» будет удалён. Сами файлы в библиотеке останутся.") },
            confirmButton = {
                TextButton(onClick = {
                    ProfileStore.delete(context, p.id)
                    toDelete = null
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun ProfileCard(
    p: Profile,
    active: Boolean,
    busy: Boolean,
    onInstall: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
) {
    val color = AppSettings.accents.getOrNull(p.colorIndex)?.second ?: AppSettings.accents[0].second
    var menu by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = if (active) BorderStroke(1.dp, color) else null,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).background(color.copy(alpha = 0.25f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center,
                ) { Text(p.emoji, fontSize = 26.sp) }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            p.name,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        if (active) {
                            Spacer(Modifier.width(8.dp))
                            Chip("Активный", color)
                        }
                    }
                    Text(
                        "Файлов: ${p.files.size}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Меню") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Изменить") }, onClick = { menu = false; onEdit() })
                        DropdownMenuItem(text = { Text("Удалить") }, onClick = { menu = false; onDelete() })
                    }
                }
            }
            if (p.note.isNotBlank()) {
                Text(p.note, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(
                onClick = onInstall,
                enabled = !busy,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (busy) "Подготовка…" else "Установить в Minecraft", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun ProfileEditor(
    initial: Profile?,
    modifier: Modifier,
    onClose: () -> Unit,
    onSave: (Profile) -> Unit,
) {
    val context = LocalContext.current
    val files = remember { ModsRepository.listAll(context) }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var note by remember { mutableStateOf(initial?.note ?: "") }
    var emoji by remember { mutableStateOf(initial?.emoji ?: EMOJIS[0]) }
    var colorIndex by remember { mutableIntStateOf(initial?.colorIndex ?: 0) }
    val selected = remember {
        mutableStateListOf<String>().also { list ->
            initial?.files?.filter { n -> files.any { it.name == n } }?.let { list.addAll(it) }
        }
    }
    val color = AppSettings.accents.getOrNull(colorIndex)?.second ?: AppSettings.accents[0].second

    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("Отмена") }
            Spacer(Modifier.weight(1f))
            Text(if (initial == null) "Новый профиль" else "Профиль", fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        Profile(
                            id = initial?.id ?: UUID.randomUUID().toString(),
                            name = name.trim(),
                            colorIndex = colorIndex,
                            emoji = emoji,
                            note = note.trim(),
                            files = files.map { it.name }.filter { it in selected },
                        )
                    )
                },
            ) { Text("Сохранить") }
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Название профиля") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Значок", fontSize = 14.sp, fontWeight = FontWeight.Medium)
            EMOJIS.chunked(6).forEach { rowItems ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { e ->
                        Box(
                            Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (e == emoji) color.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { emoji = e },
                            contentAlignment = Alignment.Center,
                        ) { Text(e, fontSize = 22.sp) }
                    }
                }
            }

            Text("Цвет", fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AppSettings.accents.forEachIndexed { i, (_, c) ->
                    ColorDot(c, selected = i == colorIndex) { colorIndex = i }
                }
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Заметка (необязательно)") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth(),
            )

            Text("Что входит в профиль (${selected.size})", fontSize = 14.sp, fontWeight = FontWeight.Medium)
            if (files.isEmpty()) {
                Text(
                    "Библиотека пуста. Сначала добавь аддоны или миры на вкладках «Аддоны» и «Миры».",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                files.forEach { f ->
                    val checked = f.name in selected
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { if (checked) selected.remove(f.name) else selected.add(f.name) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked, onCheckedChange = { on ->
                            if (on) selected.add(f.name) else selected.remove(f.name)
                        })
                        Column(Modifier.padding(end = 8.dp)) {
                            Text(f.nameWithoutExtension, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${typeLabel(f.name)} · ${formatSize(f.length())}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.size(16.dp))
        }
    }
}
