package com.archon.client.mods

import java.io.File
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.Collections
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

/**
 * Проверка файла на телефоне: до библиотеки, до загрузки в облако, после скачивания и перед установкой.
 * Это не антивирус, но она отсекает то, что реально можно подсунуть под видом мода:
 *  - переименованный .apk / .exe (снаружи zip, внутри программа);
 *  - программы внутри архива, в том числе переименованные под картинку (проверяются первые байты);
 *  - архивы в архивах (.mcpack в .mcaddon) — их тоже открываем;
 *  - пути вида ../../ и «zip-бомбы» (размер считается по реально распакованным байтам, а не по заголовку).
 *
 * Главная защита всё равно на сервере (функция scan-mod): код открыт, и проверку в приложении можно обойти.
 */
object PackValidator {
    private class Bad(message: String) : IOException(message)

    private const val MAX_ENTRIES = 30_000
    private const val MAX_UNPACKED = 1_500L * 1024 * 1024
    private const val MAX_RATIO = 150
    private const val MAX_DEPTH = 3

    private val BAD_EXT = setOf(
        "apk", "apks", "xapk", "apkm", "aab", "dex", "odex", "oat", "vdex", "so", "jar", "class",
        "exe", "dll", "sys", "msi", "scr", "com", "pif", "cpl", "bat", "cmd", "vbs", "vbe", "wsf",
        "ps1", "psm1", "hta", "lnk", "reg", "sh", "bash", "elf", "run", "deb", "rpm", "dmg", "app",
        "rar", "7z", "cab", "iso",
    )
    private val BAD_NAMES = setOf("androidmanifest.xml", "classes.dex", "resources.arsc")
    private val NESTED_EXT = setOf("mcpack", "mcaddon", "mcworld", "mctemplate", "zip")
    private val TEXT_EXT = setOf("json", "lang", "txt", "js", "ts", "mcfunction", "material", "md", "properties")

    private class Stats(val packed: Long) {
        var entries = 0
        var unpacked = 0L
        var manifest = false
        var levelDat = false
    }

    /**
     * Возвращает null, если файл прошёл проверку, иначе причину отказа.
     * strict: требовать признаки мода или мира (manifest.json / level.dat).
     * name: настоящее имя файла, если [file] временный (например, *.part).
     */
    fun check(file: File, strict: Boolean, name: String = file.name): String? {
        return try {
            val head = ByteArray(4)
            val n = file.inputStream().use { it.read(head) }
            if (n < 4 || head[0] != 'P'.code.toByte() || head[1] != 'K'.code.toByte()) {
                return "Это не архив Minecraft"
            }
            val s = Stats(file.length().coerceAtLeast(1))
            ZipFile(file).use { zf ->
                for (e in Collections.list(zf.entries())) {
                    entry(e.name, e.isDirectory, s, 0) { zf.getInputStream(e) }
                }
            }
            val ext = name.substringAfterLast('.', "").lowercase()
            if (strict || ext == "mcpack" || ext == "mcworld") {
                when (ext) {
                    "mcpack" -> if (!s.manifest) return "Внутри нет manifest.json — это не аддон"
                    "mcworld" -> if (!s.levelDat) return "Внутри нет level.dat — это не мир"
                    else -> if (!s.manifest && !s.levelDat) {
                        return "Это не похоже на мод или мир Minecraft (нет manifest.json или level.dat)"
                    }
                }
            }
            null
        } catch (e: Bad) {
            e.message
        } catch (e: Exception) {
            "Файл повреждён или это не архив"
        }
    }

    private fun entry(rawName: String, isDir: Boolean, s: Stats, depth: Int, open: () -> InputStream) {
        if (++s.entries > MAX_ENTRIES) throw Bad("Слишком много файлов внутри архива")
        val name = rawName.replace('\\', '/')
        val parts = name.split('/')
        if (name.startsWith("/") || parts.any { it == ".." } || Regex("^[A-Za-z]:").containsMatchIn(name)) {
            throw Bad("В архиве опасные пути файлов")
        }
        if (isDir || name.endsWith("/")) return
        val base = parts.last().lowercase()
        val ext = base.substringAfterLast('.', "")
        if (base in BAD_NAMES || ext in BAD_EXT) throw Bad("Внутри есть программа (${parts.last().take(50)}), это не мод Minecraft")
        if (base == "manifest.json") s.manifest = true
        if (base == "level.dat") s.levelDat = true

        open().use { input ->
            if (ext in NESTED_EXT) {
                if (depth + 1 > MAX_DEPTH) throw Bad("Слишком много архивов друг в друге")
                val zis = ZipInputStream(NoClose(input))
                while (true) {
                    val inner = zis.nextEntry ?: break
                    entry(inner.name, inner.isDirectory, s, depth + 1) { NoClose(zis) }
                }
            } else {
                scan(input, ext, s, parts.last())
            }
        }
    }

    private fun scan(input: InputStream, ext: String, s: Stats, shown: String) {
        val buf = ByteArray(64 * 1024)
        val head = ByteArray(4)
        var got = 0
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            if (got < 4) {
                val take = minOf(4 - got, n)
                System.arraycopy(buf, 0, head, got, take)
                got += take
                if (got == 4 && isProgram(head, ext)) throw Bad("Внутри спрятана программа: ${shown.take(50)}")
            }
            s.unpacked += n
            if (s.unpacked > MAX_UNPACKED) throw Bad("Архив слишком большой после распаковки")
            if (s.unpacked > 100L * 1024 * 1024 && s.unpacked / s.packed > MAX_RATIO) {
                throw Bad("Подозрительно сильно сжатый архив (похоже на zip-бомбу)")
            }
        }
    }

    private fun isProgram(b: ByteArray, ext: String): Boolean {
        val elf = b[0] == 0x7F.toByte() && b[1] == 'E'.code.toByte() && b[2] == 'L'.code.toByte() && b[3] == 'F'.code.toByte()
        val dex = b[0] == 'd'.code.toByte() && b[1] == 'e'.code.toByte() && b[2] == 'x'.code.toByte() && b[3] == '\n'.code.toByte()
        val mz = b[0] == 'M'.code.toByte() && b[1] == 'Z'.code.toByte() && ext !in TEXT_EXT
        return elf || dex || mz
    }

    /** Не даёт вложенному архиву закрыть внешний поток. */
    private class NoClose(input: InputStream) : FilterInputStream(input) {
        override fun close() {}
    }
}
