package com.archon.client.cloud

import android.content.Context
import com.archon.client.mods.ModKind
import com.archon.client.mods.ModMeta
import com.archon.client.mods.ModsRepository
import com.archon.client.mods.PackValidator
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.security.MessageDigest
import java.time.OffsetDateTime
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Session(
    val accessToken: String,
    val refreshToken: String,
    val expiresAt: Long,
    val userId: String,
    val email: String,
)

data class PlayerProfile(
    val id: String,
    val username: String,
    val bio: String = "",
    val accent: Int = 0,
    val avatarPath: String? = null,
    val bannerPath: String? = null,
    val frame: Int = 0,
    val status: String = "",
)

data class CloudMod(
    val id: String,
    val ownerId: String,
    val ownerName: String,
    val title: String,
    val description: String,
    val kind: String,
    val filePath: String,
    val fileName: String,
    val size: Long,
    val imagePath: String?,
    val downloads: Int,
    /** pending — ждёт проверки на сервере, approved — проверен, rejected — не прошёл проверку. */
    val status: String = "approved",
    /** Причина, если сервер отклонил файл. */
    val scanNote: String = "",
    /** Хэш проверенного сервером файла. После скачивания сверяем, чтобы файл не подменили. */
    val sha256: String = "",
)

/** Сообщение чата из базы. */
data class ChatRow(val id: Long, val author: String, val nick: String, val text: String, val time: Long)

/** Связь с базой Supabase: аккаунты, профили, моды и файлы. Ключ публичный, доступ защищён правилами в базе. */
object Supa {
    private const val BASE_URL = "https://trbjqrtvocfourtutray.supabase.co"
    private const val KEY = "sb_publishable_38p7huo6xmR4lP0wAxexyw_r6_5z-ee"
    const val MAX_FILE_BYTES = 50L * 1024 * 1024

    /** Корзина, куда игрок загружает мод на проверку. Она приватная: файл видит только автор. */
    const val UPLOAD_BUCKET = "uploads"

    class ApiException(val code: Int, val key: String, message: String) : IOException(message)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun clean(s: String) = s.filter { it.isLetterOrDigit() || it == '_' || it == ' ' || it == '-' }.trim()

    fun publicUrl(bucket: String, path: String) = "$BASE_URL/storage/v1/object/public/$bucket/$path"

    fun safeName(name: String): String =
        name.map { if ((it.isLetterOrDigit() && it.code < 128) || it == '.' || it == '_' || it == '-') it else '_' }
            .joinToString("")

    // ---------- низкий уровень ----------

    private fun open(path: String, method: String, token: String?): HttpURLConnection {
        val c = URL(BASE_URL + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("apikey", KEY)
        c.setRequestProperty("User-Agent", "ArchonClient")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        return c
    }

    private fun fail(code: Int, text: String): Nothing {
        var key = ""
        var msg = ""
        runCatching {
            val o = JSONObject(text)
            key = o.optString("error_code").ifBlank { o.optString("code") }.ifBlank { o.optString("statusCode") }
            msg = o.optString("msg").ifBlank { o.optString("message") }
                .ifBlank { o.optString("error_description") }.ifBlank { o.optString("error") }
        }
        throw ApiException(code, key, msg.ifBlank { "Ошибка сервера ($code)" })
    }

    private fun call(
        path: String,
        method: String,
        token: String? = null,
        body: String? = null,
        headers: Map<String, String> = emptyMap(),
    ): String {
        val c = open(path, method, token)
        try {
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) fail(code, text)
            return text
        } finally {
            c.disconnect()
        }
    }

    // ---------- аккаунт ----------

    private fun parseSession(o: JSONObject): Session {
        val user = o.getJSONObject("user")
        val expires = if (o.has("expires_at")) o.getLong("expires_at")
        else System.currentTimeMillis() / 1000 + o.optLong("expires_in", 3600)
        return Session(
            o.getString("access_token"),
            o.getString("refresh_token"),
            expires,
            user.getString("id"),
            user.optString("email"),
        )
    }

    /** Вернёт null, если почта ещё требует подтверждения. */
    fun signUp(email: String, password: String): Session? {
        val body = JSONObject().put("email", email).put("password", password).toString()
        val o = JSONObject(call("/auth/v1/signup", "POST", body = body))
        return if (o.has("access_token")) parseSession(o) else null
    }

    fun signIn(email: String, password: String): Session {
        val body = JSONObject().put("email", email).put("password", password).toString()
        return parseSession(JSONObject(call("/auth/v1/token?grant_type=password", "POST", body = body)))
    }

    fun refresh(refreshToken: String): Session {
        val body = JSONObject().put("refresh_token", refreshToken).toString()
        return parseSession(JSONObject(call("/auth/v1/token?grant_type=refresh_token", "POST", body = body)))
    }

    // ---------- профили ----------

    private fun parseProfile(o: JSONObject) = PlayerProfile(
        id = o.getString("id"),
        username = o.optString("username"),
        bio = o.optString("bio"),
        accent = o.optInt("accent", 0),
        avatarPath = if (o.isNull("avatar_path")) null else o.optString("avatar_path"),
        bannerPath = if (o.isNull("banner_path")) null else o.optString("banner_path"),
        frame = o.optInt("frame", 0),
        status = if (o.isNull("status")) "" else o.optString("status"),
    )

    private fun parseProfiles(text: String): List<PlayerProfile> {
        val a = JSONArray(text)
        return List(a.length()) { parseProfile(a.getJSONObject(it)) }
    }

    fun searchPlayers(term: String): List<PlayerProfile> {
        val c = clean(term)
        val filter = if (c.isBlank()) "" else "&username=ilike." + enc("*$c*")
        return parseProfiles(call("/rest/v1/profiles?select=*&order=created_at.desc&limit=40$filter", "GET"))
    }

    fun getProfile(id: String): PlayerProfile? =
        parseProfiles(call("/rest/v1/profiles?select=*&id=eq.$id", "GET")).firstOrNull()

    fun saveProfile(token: String, p: PlayerProfile): PlayerProfile {
        val body = JSONObject()
            .put("id", p.id)
            .put("username", p.username)
            .put("bio", p.bio)
            .put("accent", p.accent)
            .put("avatar_path", p.avatarPath ?: JSONObject.NULL)
            .put("banner_path", p.bannerPath ?: JSONObject.NULL)
            .put("frame", p.frame)
            .put("status", p.status)
            .toString()
        val text = call(
            "/rest/v1/profiles?on_conflict=id", "POST", token, body,
            mapOf("Prefer" to "resolution=merge-duplicates,return=representation"),
        )
        return parseProfiles(text).first()
    }

    // ---------- моды ----------

    private fun parseMods(text: String): List<CloudMod> {
        val a = JSONArray(text)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            CloudMod(
                id = o.getString("id"),
                ownerId = o.getString("owner"),
                ownerName = o.optJSONObject("profiles")?.optString("username").orEmpty(),
                title = o.optString("title"),
                description = o.optString("description"),
                kind = o.optString("kind"),
                filePath = o.getString("file_path"),
                fileName = o.getString("file_name"),
                size = o.optLong("size"),
                imagePath = if (o.isNull("image_path")) null else o.optString("image_path"),
                downloads = o.optInt("downloads"),
                status = o.optString("status").ifBlank { "approved" },
                scanNote = if (o.isNull("scan_note")) "" else o.optString("scan_note"),
                sha256 = if (o.isNull("sha256")) "" else o.optString("sha256"),
            )
        }
    }

    fun listMods(
        kind: String?, term: String, ownerId: String?,
        popular: Boolean = false, hideReported: Boolean = true,
    ): List<CloudMod> {
        val order = if (popular) "downloads.desc,created_at.desc" else "created_at.desc"
        val sb = StringBuilder("/rest/v1/mods?select=*,profiles(username)&order=$order&limit=50")
        // Чужие моды показываем только проверенные сервером. Это же правило стоит и в базе (RLS),
        // так что обойти его, убрав фильтр из кода, не получится.
        if (hideReported) sb.append("&reports=lt.3&status=eq.approved")
        if (kind != null) sb.append("&kind=eq.").append(kind)
        if (ownerId != null) sb.append("&owner=eq.").append(ownerId)
        val c = clean(term)
        if (c.isNotBlank()) sb.append("&title=ilike.").append(enc("*$c*"))
        return parseMods(call(sb.toString(), "GET"))
    }

    fun insertMod(
        token: String, ownerId: String, title: String, description: String, kind: String,
        filePath: String, fileName: String, size: Long, imagePath: String?,
    ): String {
        val body = JSONObject()
            .put("owner", ownerId)
            .put("title", title)
            .put("description", description)
            .put("kind", kind)
            .put("file_path", filePath)
            .put("file_name", fileName)
            .put("size", size)
            .put("image_path", imagePath ?: JSONObject.NULL)
            .toString()
        val text = call("/rest/v1/mods", "POST", token, body, mapOf("Prefer" to "return=representation"))
        return JSONArray(text).getJSONObject(0).getString("id")
    }

    /** Результат серверной проверки файла. */
    data class ScanResult(val ok: Boolean, val reason: String)

    /** Вызов серверной функции scan-mod. */
    private fun function(token: String, body: JSONObject, timeoutMs: Int): JSONObject {
        val c = open("/functions/v1/scan-mod", "POST", token)
        c.readTimeout = timeoutMs
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) fail(code, text)
            return JSONObject(text)
        } finally {
            c.disconnect()
        }
    }

    /**
     * Просит сервер проверить загруженный мод (Edge Function scan-mod).
     * Пока проверка не пройдена, мод видит только автор.
     */
    fun scanMod(token: String, modId: String): ScanResult {
        val o = function(token, JSONObject().put("mod_id", modId), 120000)
        return ScanResult(o.optString("status") == "approved", o.optString("reason"))
    }

    /**
     * Удаляет мод вместе с файлами. Проверенный файл лежит в корзине, куда игрок писать не может,
     * поэтому удаляет его сервер.
     */
    fun deleteMod(token: String, mod: CloudMod) {
        function(token, JSONObject().put("action", "delete").put("mod_id", mod.id), 30000)
    }

    /** Удаляет картинку из облака, чтобы старые аватарки не занимали место. Ошибки не важны. */
    fun deleteImage(token: String, path: String) {
        runCatching { call("/storage/v1/object/images/$path", "DELETE", token) }
    }

    /** Удаляет свой файл из корзины загрузок (если мод не удалось создать). Ошибки не важны. */
    fun deleteUpload(token: String, path: String) {
        runCatching { call("/storage/v1/object/$UPLOAD_BUCKET/$path", "DELETE", token) }
    }

    fun reportMod(token: String, modId: String, reporterId: String, reason: String) {
        val body = JSONObject().put("mod_id", modId).put("reporter", reporterId).put("reason", reason).toString()
        call("/rest/v1/reports", "POST", token, body, mapOf("Prefer" to "return=minimal"))
    }

    /** Засчитывает скачивание. Один аккаунт — одно скачивание мода, поэтому нужен вход. */
    fun countDownload(token: String, id: String) {
        call("/rest/v1/rpc/count_download", "POST", token, JSONObject().put("mod_id", id).toString())
    }

    // ---------- чат ----------

    private fun parseChat(text: String): List<ChatRow> {
        val a = JSONArray(text)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            ChatRow(
                id = o.getLong("id"),
                author = o.optString("author"),
                nick = o.optString("nick").ifBlank { "Игрок" },
                text = o.optString("text"),
                time = runCatching { OffsetDateTime.parse(o.getString("created_at")).toEpochSecond() }
                    .getOrDefault(System.currentTimeMillis() / 1000),
            )
        }
    }

    /** Последние сообщения комнаты (или только новее [afterId]), от старых к новым. */
    fun chatMessages(room: String, afterId: Long): List<ChatRow> {
        val base = "/rest/v1/chat_messages?select=id,author,nick,text,created_at&room=eq.${enc(room)}"
        return if (afterId <= 0) {
            parseChat(call("$base&order=id.desc&limit=60", "GET")).reversed()
        } else {
            parseChat(call("$base&id=gt.$afterId&order=id.asc&limit=100", "GET"))
        }
    }

    /** Ник и время ставит сама база: подделать их нельзя. */
    fun sendChat(token: String, room: String, text: String) {
        val body = JSONObject().put("room", room).put("text", text).toString()
        call("/rest/v1/chat_messages", "POST", token, body, mapOf("Prefer" to "return=minimal"))
    }

    // ---------- файлы ----------

    private fun put(
        token: String, bucket: String, path: String, length: Long, contentType: String,
        writer: (OutputStream) -> Unit,
    ) {
        val c = open("/storage/v1/object/$bucket/$path", "POST", token)
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", contentType)
            // Перезаписывать уже загруженные файлы нельзя: иначе проверенный мод можно подменить вирусом
            c.setRequestProperty("x-upsert", "false")
            c.setFixedLengthStreamingMode(length)
            c.outputStream.use { writer(it) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) fail(code, text)
        } finally {
            c.disconnect()
        }
    }

    fun uploadFile(token: String, bucket: String, path: String, file: File) =
        put(token, bucket, path, file.length(), "application/octet-stream") { out ->
            file.inputStream().use { it.copyTo(out) }
        }

    fun uploadBytes(token: String, bucket: String, path: String, bytes: ByteArray) =
        put(token, bucket, path, bytes.size.toLong(), "image/jpeg") { it.write(bytes) }

    private fun fetchBytes(url: String, maxBytes: Int): ByteArray? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 30000
        try {
            if (c.responseCode != 200 || c.contentLengthLong > maxBytes) return null
            // сервер может не сообщить размер заранее, поэтому считаем байты сами
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(16 * 1024)
            c.inputStream.use { input ->
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (out.size() + n > maxBytes) return null
                    out.write(buf, 0, n)
                }
            }
            return out.toByteArray()
        } finally {
            c.disconnect()
        }
    }

    /** Скачивает мод из облака в библиотеку приложения. */
    fun download(context: Context, mod: CloudMod): File {
        val name = File(mod.fileName).name
        if (ModKind.entries.none { it.accepts(name) }) throw IOException("Этот тип файла не поддерживается")
        val dir = ModsRepository.modsDir(context)
        // Тот же мод скачиваем поверх старой копии. Другой мод с таким же именем файла
        // получает своё имя, чтобы не затереть чужой файл.
        val dest = ModMeta.fileForCloud(context, mod.id) ?: ModsRepository.uniqueFile(dir, name)
        val tmp = File(dir, "${dest.name}.part")
        val c = URL(publicUrl("mods", mod.filePath)).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 30000
        try {
            val code = c.responseCode
            if (code == 404 || code == 400) throw IOException("Файл удалён автором")
            if (code != 200) throw IOException("Ошибка скачивания ($code)")
            val md = MessageDigest.getInstance("SHA-256")
            var total = 0L
            c.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_FILE_BYTES) throw IOException("Файл больше 50 МБ")
                        md.update(buf, 0, n)
                        out.write(buf, 0, n)
                    }
                }
            }
            val hash = md.digest().joinToString("") { "%02x".format(it) }
            if (mod.sha256.isNotBlank() && !mod.sha256.equals(hash, ignoreCase = true)) {
                throw IOException("Файл на сервере не совпадает с проверенным, скачивание отменено")
            }
            val isZip = tmp.inputStream().use { it.read() == 'P'.code && it.read() == 'K'.code }
            if (!isZip) throw IOException("Скачался не файл мода")
            // вторая защита: файл проверяется и на телефоне
            PackValidator.check(tmp, strict = false, name = name)?.let {
                throw IOException("Файл не прошёл проверку безопасности: $it")
            }
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("Не удалось сохранить файл")
        } finally {
            c.disconnect()
            tmp.delete()
        }
        val image = mod.imagePath?.let { runCatching { fetchBytes(publicUrl("images", it), 5_000_000) }.getOrNull() }
        ModMeta.saveCloud(context, dest.name, mod.id, mod.title, mod.description, image)
        return dest
    }
}
