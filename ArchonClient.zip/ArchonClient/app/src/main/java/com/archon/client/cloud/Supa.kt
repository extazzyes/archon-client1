package com.archon.client.cloud

import android.content.Context
import com.archon.client.mods.ModKind
import com.archon.client.mods.ModMeta
import com.archon.client.mods.ModsRepository
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Session(
    val accessToken: String,
    val refreshToken: String,
    val expiresAt: Long,
    val userId: String,
    val email: String,
)

data class PlayerProfile(
    val id: String,
    val username: String,
    val bio: String = "",
    val accent: Int = 0,
    val avatarPath: String? = null,
    val bannerPath: String? = null,
)

data class CloudMod(
    val id: String,
    val ownerId: String,
    val ownerName: String,
    val title: String,
    val description: String,
    val kind: String,
    val filePath: String,
    val fileName: String,
    val size: Long,
    val imagePath: String?,
    val downloads: Int,
)

/** Связь с базой Supabase: аккаунты, профили, моды и файлы. Ключ публичный, доступ защищён правилами в базе. */
object Supa {
    private const val BASE_URL = "https://trbjqrtvocfourtutray.supabase.co"
    private const val KEY = "sb_publishable_38p7huo6xmR4lP0wAxexyw_r6_5z-ee"
    const val MAX_FILE_BYTES = 50L * 1024 * 1024

    class ApiException(val code: Int, val key: String, message: String) : IOException(message)

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun clean(s: String) = s.filter { it.isLetterOrDigit() || it == '_' || it == ' ' || it == '-' }.trim()

    fun publicUrl(bucket: String, path: String) = "$BASE_URL/storage/v1/object/public/$bucket/$path"

    fun safeName(name: String): String =
        name.map { if ((it.isLetterOrDigit() && it.code < 128) || it == '.' || it == '_' || it == '-') it else '_' }
            .joinToString("")

    // ---------- низкий уровень ----------

    private fun open(path: String, method: String, token: String?): HttpURLConnection {
        val c = URL(BASE_URL + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("apikey", KEY)
        c.setRequestProperty("User-Agent", "ArchonClient")
        if (token != null) c.setRequestProperty("Authorization", "Bearer $token")
        return c
    }

    private fun fail(code: Int, text: String): Nothing {
        var key = ""
        var msg = ""
        runCatching {
            val o = JSONObject(text)
            key = o.optString("error_code").ifBlank { o.optString("code") }.ifBlank { o.optString("statusCode") }
            msg = o.optString("msg").ifBlank { o.optString("message") }
                .ifBlank { o.optString("error_description") }.ifBlank { o.optString("error") }
        }
        throw ApiException(code, key, msg.ifBlank { "Ошибка сервера ($code)" })
    }

    private fun call(
        path: String,
        method: String,
        token: String? = null,
        body: String? = null,
        headers: Map<String, String> = emptyMap(),
    ): String {
        val c = open(path, method, token)
        try {
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) fail(code, text)
            return text
        } finally {
            c.disconnect()
        }
    }

    // ---------- аккаунт ----------

    private fun parseSession(o: JSONObject): Session {
        val user = o.getJSONObject("user")
        val expires = if (o.has("expires_at")) o.getLong("expires_at")
        else System.currentTimeMillis() / 1000 + o.optLong("expires_in", 3600)
        return Session(
            o.getString("access_token"),
            o.getString("refresh_token"),
            expires,
            user.getString("id"),
            user.optString("email"),
        )
    }

    /** Вернёт null, если почта ещё требует подтверждения. */
    fun signUp(email: String, password: String): Session? {
        val body = JSONObject().put("email", email).put("password", password).toString()
        val o = JSONObject(call("/auth/v1/signup", "POST", body = body))
        return if (o.has("access_token")) parseSession(o) else null
    }

    fun signIn(email: String, password: String): Session {
        val body = JSONObject().put("email", email).put("password", password).toString()
        return parseSession(JSONObject(call("/auth/v1/token?grant_type=password", "POST", body = body)))
    }

    fun refresh(refreshToken: String): Session {
        val body = JSONObject().put("refresh_token", refreshToken).toString()
        return parseSession(JSONObject(call("/auth/v1/token?grant_type=refresh_token", "POST", body = body)))
    }

    // ---------- профили ----------

    private fun parseProfile(o: JSONObject) = PlayerProfile(
        id = o.getString("id"),
        username = o.optString("username"),
        bio = o.optString("bio"),
        accent = o.optInt("accent", 0),
        avatarPath = if (o.isNull("avatar_path")) null else o.optString("avatar_path"),
        bannerPath = if (o.isNull("banner_path")) null else o.optString("banner_path"),
    )

    private fun parseProfiles(text: String): List<PlayerProfile> {
        val a = JSONArray(text)
        return List(a.length()) { parseProfile(a.getJSONObject(it)) }
    }

    fun searchPlayers(term: String): List<PlayerProfile> {
        val c = clean(term)
        val filter = if (c.isBlank()) "" else "&username=ilike." + enc("*$c*")
        return parseProfiles(call("/rest/v1/profiles?select=*&order=created_at.desc&limit=40$filter", "GET"))
    }

    fun getProfile(id: String): PlayerProfile? =
        parseProfiles(call("/rest/v1/profiles?select=*&id=eq.$id", "GET")).firstOrNull()

    fun saveProfile(token: String, p: PlayerProfile): PlayerProfile {
        val body = JSONObject()
            .put("id", p.id)
            .put("username", p.username)
            .put("bio", p.bio)
            .put("accent", p.accent)
            .put("avatar_path", p.avatarPath ?: JSONObject.NULL)
            .put("banner_path", p.bannerPath ?: JSONObject.NULL)
            .toString()
        val text = call(
            "/rest/v1/profiles?on_conflict=id", "POST", token, body,
            mapOf("Prefer" to "resolution=merge-duplicates,return=representation"),
        )
        return parseProfiles(text).first()
    }

    // ---------- моды ----------

    private fun parseMods(text: String): List<CloudMod> {
        val a = JSONArray(text)
        return List(a.length()) { i ->
            val o = a.getJSONObject(i)
            CloudMod(
                id = o.getString("id"),
                ownerId = o.getString("owner"),
                ownerName = o.optJSONObject("profiles")?.optString("username").orEmpty(),
                title = o.optString("title"),
                description = o.optString("description"),
                kind = o.optString("kind"),
                filePath = o.getString("file_path"),
                fileName = o.getString("file_name"),
                size = o.optLong("size"),
                imagePath = if (o.isNull("image_path")) null else o.optString("image_path"),
                downloads = o.optInt("downloads"),
            )
        }
    }

    fun listMods(kind: String?, term: String, ownerId: String?): List<CloudMod> {
        val sb = StringBuilder("/rest/v1/mods?select=*,profiles(username)&order=created_at.desc&limit=50")
        if (kind != null) sb.append("&kind=eq.").append(kind)
        if (ownerId != null) sb.append("&owner=eq.").append(ownerId)
        val c = clean(term)
        if (c.isNotBlank()) sb.append("&title=ilike.").append(enc("*$c*"))
        return parseMods(call(sb.toString(), "GET"))
    }

    fun insertMod(
        token: String, ownerId: String, title: String, description: String, kind: String,
        filePath: String, fileName: String, size: Long, imagePath: String?,
    ) {
        val body = JSONObject()
            .put("owner", ownerId)
            .put("title", title)
            .put("description", description)
            .put("kind", kind)
            .put("file_path", filePath)
            .put("file_name", fileName)
            .put("size", size)
            .put("image_path", imagePath ?: JSONObject.NULL)
            .toString()
        call("/rest/v1/mods", "POST", token, body, mapOf("Prefer" to "return=minimal"))
    }

    fun deleteMod(token: String, mod: CloudMod) {
        call("/rest/v1/mods?id=eq.${mod.id}", "DELETE", token)
        runCatching { call("/storage/v1/object/mods/${mod.filePath}", "DELETE", token) }
        mod.imagePath?.let { p -> runCatching { call("/storage/v1/object/images/$p", "DELETE", token) } }
    }

    fun countDownload(id: String) {
        call("/rest/v1/rpc/count_download", "POST", body = JSONObject().put("mod_id", id).toString())
    }

    // ---------- файлы ----------

    private fun put(
        token: String, bucket: String, path: String, length: Long, contentType: String,
        writer: (OutputStream) -> Unit,
    ) {
        val c = open("/storage/v1/object/$bucket/$path", "POST", token)
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", contentType)
            c.setRequestProperty("x-upsert", "true")
            c.setFixedLengthStreamingMode(length)
            c.outputStream.use { writer(it) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) fail(code, text)
        } finally {
            c.disconnect()
        }
    }

    fun uploadFile(token: String, bucket: String, path: String, file: File) =
        put(token, bucket, path, file.length(), "application/octet-stream") { out ->
            file.inputStream().use { it.copyTo(out) }
        }

    fun uploadBytes(token: String, bucket: String, path: String, bytes: ByteArray) =
        put(token, bucket, path, bytes.size.toLong(), "image/jpeg") { it.write(bytes) }

    private fun fetchBytes(url: String, maxBytes: Int): ByteArray? {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 30000
        try {
            if (c.responseCode != 200 || c.contentLengthLong > maxBytes) return null
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    /** Скачивает мод из облака в библиотеку приложения. */
    fun download(context: Context, mod: CloudMod): File {
        val name = File(mod.fileName).name
        if (ModKind.entries.none { it.accepts(name) }) throw IOException("Этот тип файла не поддерживается")
        val dir = ModsRepository.modsDir(context)
        val dest = File(dir, name)
        val tmp = File(dir, "$name.part")
        val c = URL(publicUrl("mods", mod.filePath)).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 30000
        try {
            val code = c.responseCode
            if (code == 404) throw IOException("Файл удалён автором")
            if (code != 200) throw IOException("Ошибка скачивания ($code)")
            c.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            val isZip = tmp.inputStream().use { it.read() == 'P'.code && it.read() == 'K'.code }
            if (!isZip) throw IOException("Скачался не файл мода")
            if (dest.exists()) dest.delete()
            if (!tmp.renameTo(dest)) throw IOException("Не удалось сохранить файл")
        } finally {
            c.disconnect()
            tmp.delete()
        }
        val image = mod.imagePath?.let { runCatching { fetchBytes(publicUrl("images", it), 5_000_000) }.getOrNull() }
        ModMeta.saveCloud(context, name, mod.title, mod.description, image)
        return dest
    }
}
