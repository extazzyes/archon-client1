package com.archon.client.minecraft

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

sealed interface McStatus {
    data object NotInstalled : McStatus
    data class Installed(val versionName: String) : McStatus
}

object MinecraftLauncher {
    const val PACKAGE = "com.mojang.minecraftpe"

    @Suppress("DEPRECATION")
    fun getStatus(context: Context): McStatus = try {
        val info = context.packageManager.getPackageInfo(PACKAGE, 0)
        McStatus.Installed(info.versionName ?: "?")
    } catch (e: PackageManager.NameNotFoundException) {
        McStatus.NotInstalled
    }

    fun launch(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun openStore(context: Context) {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PACKAGE"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(market)
        } catch (e: Exception) {
            val web = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=$PACKAGE")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(web)
        }
    }
}
