package com.archon.client.minecraft

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

sealed interface McStatus {
    data object NotInstalled : McStatus
    data class Installed(val versionName: String, val supported: Boolean) : McStatus
}

object MinecraftLauncher {
    const val PACKAGE = "com.mojang.minecraftpe"

    // Максимальная поддерживаемая версия (включительно): 26.50
    const val MAX_MAJOR = 26
    const val MAX_MINOR = 50

    @Suppress("DEPRECATION")
    fun getStatus(context: Context): McStatus = try {
        val info = context.packageManager.getPackageInfo(PACKAGE, 0)
        val name = info.versionName ?: "?"
        McStatus.Installed(name, isSupported(name))
    } catch (e: PackageManager.NameNotFoundException) {
        McStatus.NotInstalled
    }

    /** Старые версии (1.x) считаются поддерживаемыми, новые сравниваются с 26.50. */
    fun isSupported(versionName: String): Boolean {
        val parts = versionName.split(".").mapNotNull { it.toIntOrNull() }
        if (parts.size < 2) return true
        val (major, minor) = parts
        return when {
            major < MAX_MAJOR -> true
            major == MAX_MAJOR -> minor <= MAX_MINOR
            else -> false
        }
    }

    fun launch(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    fun openStore(context: Context) {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PACKAGE"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(market)
        } catch (e: Exception) {
            val web = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=$PACKAGE")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(web)
        }
    }
}
