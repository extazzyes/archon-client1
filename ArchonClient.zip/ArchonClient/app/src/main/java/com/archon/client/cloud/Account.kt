package com.archon.client.cloud

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

/** Текущий вход в аккаунт и профиль игрока. */
object Account {
    private const val PREFS = "archon_account"

    var session by mutableStateOf<Session?>(null)
        private set
    var profile by mutableStateOf<PlayerProfile?>(null)
        private set
    var profileError by mutableStateOf<String?>(null)
        private set
    var profileChecked by mutableStateOf(false)
        private set

    /** Обновлять вход может только один запрос за раз (иначе Supabase считает старый ключ украденным и выкидывает). */
    private val refreshLock = Mutex()

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context) {
        val p = prefs(context)
        val access = p.getString("access", null)
        val refresh = p.getString("refresh", null)
        val uid = p.getString("uid", null)
        if (access != null && refresh != null && uid != null) {
            session = Session(access, refresh, p.getLong("exp", 0), uid, p.getString("email", "") ?: "")
        }
    }

    private fun setSession(context: Context, s: Session?) {
        session = s
        val e = prefs(context).edit()
        if (s == null) {
            e.clear()
        } else {
            e.putString("access", s.accessToken).putString("refresh", s.refreshToken)
                .putLong("exp", s.expiresAt).putString("uid", s.userId).putString("email", s.email)
        }
        e.apply()
    }

    fun updateProfile(p: PlayerProfile) {
        profile = p
        profileError = null
    }

    fun friendly(e: Throwable): String = when (e) {
        is UnknownHostException -> "Нет интернета или сервер недоступен"
        is SocketTimeoutException -> "Время ожидания истекло, попробуй ещё раз"
        is Supa.ApiException -> when (e.key) {
            "invalid_credentials" -> "Неверная почта или пароль"
            "user_already_exists", "email_exists" -> "Эта почта уже зарегистрирована. Войди в аккаунт"
            "weak_password" -> "Слишком простой пароль (нужно минимум 6 символов)"
            "email_address_invalid", "validation_failed" -> "Проверь адрес почты"
            "over_email_send_rate_limit", "over_request_rate_limit" -> "Слишком много попыток, подожди немного"
            "email_not_confirmed" -> "Почта не подтверждена. Открой письмо и подтверди её"
            "23505", "409" -> duplicate(e)
            else -> when {
                e.code == 409 -> duplicate(e)
                e.code == 413 -> "Файл слишком большой (лимит 50 МБ)"
                else -> e.message ?: "Ошибка ${e.code}"
            }
        }
        is IOException -> e.message ?: "Ошибка сети"
        else -> e.message ?: e.javaClass.simpleName
    }

    /** Раньше любая ошибка «уже существует» показывалась как «ник занят», даже при загрузке файла. */
    private fun duplicate(e: Supa.ApiException): String {
        val m = e.message.orEmpty()
        return when {
            m.contains("username", ignoreCase = true) -> "Этот ник уже занят"
            m.contains("Duplicate", ignoreCase = true) || m.contains("already exists", ignoreCase = true) -> "Такой файл уже загружен"
            else -> "Такая запись уже есть"
        }
    }

    /** Возвращает текст ошибки или null, если вход выполнен. */
    suspend fun signIn(context: Context, email: String, password: String): String? = try {
        val s = withContext(Dispatchers.IO) { Supa.signIn(email.trim(), password) }
        setSession(context, s)
        null
    } catch (e: Exception) {
        friendly(e)
    }

    /** Возвращает текст ошибки или подсказки, либо null, если вход выполнен. */
    suspend fun signUp(context: Context, email: String, password: String): String? = try {
        val s = withContext(Dispatchers.IO) { Supa.signUp(email.trim(), password) }
        if (s == null) {
            "Аккаунт создан. Проверь почту: нужно подтвердить адрес, потом войди."
        } else {
            setSession(context, s)
            null
        }
    } catch (e: Exception) {
        friendly(e)
    }

    fun signOut(context: Context) {
        setSession(context, null)
        profile = null
        profileError = null
        profileChecked = false
    }

    suspend fun refreshProfile() {
        val s = session ?: return
        profileError = null
        try {
            val p = withContext(Dispatchers.IO) { Supa.getProfile(s.userId) }
            if (p != null) profile = p
            // если профиля ещё нет, экран предложит создать его
            else profile = null
        } catch (e: Exception) {
            profileError = friendly(e)
        } finally {
            profileChecked = true
        }
    }

    /**
     * Обновляет вход. Если несколько запросов одновременно увидели устаревший ключ,
     * обновляет только первый, остальные берут уже свежий.
     */
    private suspend fun freshSession(context: Context, used: Session, force: Boolean): Session = refreshLock.withLock {
        val cur = session ?: throw IOException("Нужно войти в аккаунт")
        if (cur.accessToken != used.accessToken) return@withLock cur // кто-то уже обновил, пока мы ждали
        if (!force && cur.expiresAt - 60 >= System.currentTimeMillis() / 1000) return@withLock cur
        try {
            val fresh = withContext(Dispatchers.IO) { Supa.refresh(cur.refreshToken) }
            setSession(context, fresh)
            fresh
        } catch (e: Supa.ApiException) {
            // выходим из аккаунта, только если сервер сказал, что вход недействителен, а не при сбое сервера
            if (e.code in 400..499 && e.code != 429) {
                signOut(context)
                throw IOException("Сессия истекла, войди снова")
            }
            throw e
        }
    }

    /**
     * Выполняет запрос от имени пользователя и сам обновляет вход, если он устарел.
     * В [block] должен быть ОДИН запрос: при ошибке 401 блок повторяется целиком.
     */
    suspend fun <T> authed(context: Context, block: (String) -> T): T {
        var s = session ?: throw IOException("Нужно войти в аккаунт")
        if (s.expiresAt - 60 < System.currentTimeMillis() / 1000) s = freshSession(context, s, force = false)
        return try {
            withContext(Dispatchers.IO) { block(s.accessToken) }
        } catch (e: Supa.ApiException) {
            if (e.code == 401) {
                val fresh = freshSession(context, s, force = true)
                withContext(Dispatchers.IO) { block(fresh.accessToken) }
            } else {
                throw e
            }
        }
    }
}
