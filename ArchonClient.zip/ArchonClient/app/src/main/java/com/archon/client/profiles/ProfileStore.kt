package com.archon.client.profiles

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.archon.client.settings.AppSettings
import org.json.JSONArray
import org.json.JSONObject

data class Profile(
    val id: String,
    val name: String,
    val colorIndex: Int,
    val emoji: String,
    val note: String,
    val files: List<String>,
)

object ProfileStore {
    private const val PREFS = "archon"

    val profiles = mutableStateListOf<Profile>()

    var activeId by mutableStateOf<String?>(null)
        private set

    val active: Profile? get() = profiles.firstOrNull { it.id == activeId }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context) {
        val p = prefs(context)
        profiles.clear()
        runCatching {
            val arr = JSONArray(p.getString("profiles", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val files = o.optJSONArray("files")
                profiles += Profile(
                    id = o.getString("id"),
                    name = o.optString("name"),
                    colorIndex = o.optInt("color", 0),
                    emoji = o.optString("emoji", "🎮"),
                    note = o.optString("note"),
                    files = if (files == null) emptyList() else List(files.length()) { files.getString(it) },
                )
            }
        }
        activeId = p.getString("active_profile", null)
        refreshTheme()
    }

    private fun save(context: Context) {
        val arr = JSONArray()
        profiles.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("color", it.colorIndex)
                    .put("emoji", it.emoji)
                    .put("note", it.note)
                    .put("files", JSONArray(it.files))
            )
        }
        prefs(context).edit()
            .putString("profiles", arr.toString())
            .putString("active_profile", activeId)
            .apply()
    }

    fun upsert(context: Context, profile: Profile) {
        val i = profiles.indexOfFirst { it.id == profile.id }
        if (i >= 0) profiles[i] = profile else profiles.add(profile)
        save(context)
        refreshTheme()
    }

    fun delete(context: Context, id: String) {
        profiles.removeAll { it.id == id }
        if (activeId == id) activeId = null
        save(context)
        refreshTheme()
    }

    fun setActive(context: Context, id: String?) {
        activeId = id
        save(context)
        refreshTheme()
    }

    /** Если включено, приложение берёт цвет активного профиля. */
    fun refreshTheme() {
        val color = if (AppSettings.profileColor) {
            active?.let { AppSettings.accents.getOrNull(it.colorIndex)?.second }
        } else null
        AppSettings.setOverride(color)
    }
}
