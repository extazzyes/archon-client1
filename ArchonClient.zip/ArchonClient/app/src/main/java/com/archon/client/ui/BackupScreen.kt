package com.archon.client.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archon.client.backup.BackupManager
import com.archon.client.minecraft.MinecraftLauncher
import com.archon.client.settings.AppSettings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmtTime(ms: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.forLanguageTag("ru")).format(Date(ms))

private fun newTaskIntent(intent: Intent): Intent = intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

private fun openUrl(context: Context, url: String) {
    runCatching { context.startActivity(newTaskIntent(Intent(Intent.ACTION_VIEW, Uri.parse(url)))) }
}

private fun openShizukuStore(context: Context) {
    try {
        context.startActivity(newTaskIntent(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${BackupManager.SHIZUKU_PACKAGE}"))))
    } catch (_: Exception) {
        openUrl(context, "https://play.google.com/store/apps/details?id=${BackupManager.SHIZUKU_PACKAGE}")
    }
}

private fun openShizuku(context: Context) {
    if (!BackupManager.openShizuku(context)) {
        Toast.makeText(context, "Не удалось открыть Shizuku. Он установлен?", Toast.LENGTH_SHORT).show()
    }
}

private fun openDeveloperSettings(context: Context) {
    runCatching { context.startActivity(newTaskIntent(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))) }
}

@Composable
fun BackupScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        BackupManager.init(context)
        BackupManager.refresh(context)
    }

    val setup = BackupManager.setup
    val enabled = AppSettings.worldBackupEnabled
    val active = enabled || BackupManager.wantEnable
    var restoreTarget by remember { mutableStateOf<BackupManager.BackupInfo?>(null) }
    var deleteTarget by remember { mutableStateOf<BackupManager.BackupInfo?>(null) }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Резервные копии миров", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        SettingsCard("Как это работает") {
            Text(
                "Archon сам копирует твои миры Minecraft в папку Archon/Backups во внутренней памяти. " +
                    "Выбирать папки не нужно: доступ к ним даёт Shizuku. Копии делаются при открытии Archon " +
                    "и перед запуском Minecraft, и только для тех миров, которые изменились.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SwitchRow("Автоматическая копия миров", "Выключена, пока ты её не включишь", active) {
                BackupManager.setEnabled(context, it)
            }
        }

        if (active && setup != BackupManager.Setup.Ready) {
            SetupGuide()
        }
        if (enabled && setup == BackupManager.Setup.Ready) {
            ManageSection(onRestore = { restoreTarget = it }, onDelete = { deleteTarget = it })
        }

        SettingsCard("Где лежат копии") {
            Text(
                "Папка Archon/Backups во внутренней памяти телефона. Это обычные файлы .mcworld: нажми на такой файл " +
                    "в диспетчере файлов, и Minecraft импортирует мир. Так же можно перенести мир на другой телефон или компьютер.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }

    restoreTarget?.let { b ->
        AlertDialog(
            onDismissRequest = { restoreTarget = null },
            title = { Text("Восстановить мир?") },
            text = {
                Text(
                    "Я создам новый мир «${b.world}» из копии от ${fmtTime(b.time)}. Существующие миры не изменятся. " +
                        "Перед этим полностью закрой Minecraft.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    BackupManager.restore(context, b.file)
                    restoreTarget = null
                }) { Text("Восстановить") }
            },
            dismissButton = { TextButton(onClick = { restoreTarget = null }) { Text("Отмена") } },
        )
    }
    deleteTarget?.let { b ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Удалить копию?") },
            text = { Text("Копия «${b.world}» от ${fmtTime(b.time)} будет удалена безвозвратно.") },
            confirmButton = {
                TextButton(onClick = {
                    BackupManager.delete(context, b.file)
                    deleteTarget = null
                }) { Text("Удалить", color = Warn) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Отмена") } },
        )
    }
}

// ---------------------------------------------------------------- инструкция

@Composable
private fun StepBlock(
    number: Int,
    title: String,
    done: Boolean,
    expanded: Boolean,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.size(26.dp).clip(CircleShape).background(if (done) Ok else MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                if (done) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                } else {
                    Text("$number", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.weight(1f))
        }
        if (expanded && !done) content()
    }
}

@Composable
private fun Hint(text: String) {
    Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun SetupGuide() {
    val context = LocalContext.current
    val setup = BackupManager.setup
    val installed = setup != BackupManager.Setup.NotInstalled
    val started = setup == BackupManager.Setup.Ready || setup == BackupManager.Setup.NoPermission
    val denied = BackupManager.permissionBlocked

    SettingsCard("Настройка: 3 шага") {
        Hint("Сделай по порядку. Как только Shizuku заработает, окно доступа появится само, а копии включатся без лишних нажатий.")

        StepBlock(1, "Установи Shizuku", done = installed, expanded = !installed) {
            Hint(
                "Shizuku это бесплатное приложение, которое даёт Archon безопасный доступ к папке Minecraft. " +
                    "Установи его и вернись сюда.",
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openShizukuStore(context) }, shape = RoundedCornerShape(12.dp)) { Text("Google Play") }
                OutlinedButton(
                    onClick = { openUrl(context, "https://github.com/RikkaApps/Shizuku/releases") },
                    shape = RoundedCornerShape(12.dp),
                ) { Text("GitHub") }
            }
        }

        StepBlock(2, "Запусти Shizuku", done = started, expanded = installed && !started) {
            if (Build.VERSION.SDK_INT >= 30) {
                Hint(
                    "1. Включи режим разработчика: Настройки → О телефоне → семь раз нажми на «Номер сборки».\n\n" +
                        "2. Подключись к Wi-Fi. Настройки → Для разработчиков → включи «Отладка по USB» и «Беспроводная отладка».\n\n" +
                        "3. Открой Shizuku → «Запуск через беспроводную отладку» → «Сопряжение». В настройках телефона нажми " +
                        "«Подключить устройство с помощью кода» и введи код из уведомления Shizuku.\n\n" +
                        "4. Вернись в Shizuku и нажми «Запустить». Должно появиться «Shizuku работает».",
                )
                Hint(
                    "Важно: после каждой перезагрузки телефона этот шаг нужно повторить, нужен Wi-Fi. " +
                        "Если сопряжение не идёт, разреши Shizuku работу в фоне. На Xiaomi в настройках уведомлений " +
                        "выбери стиль шторки «Android».",
                )
            } else {
                Hint(
                    "На Android 10 и ниже без компьютера не обойтись: подключи телефон по USB и выполни команду, " +
                        "которую показывает Shizuku (раздел «Запуск через компьютер»). После перезагрузки телефона " +
                        "это нужно повторить.",
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { openShizuku(context) }, shape = RoundedCornerShape(12.dp)) { Text("Открыть Shizuku") }
                OutlinedButton(onClick = { openDeveloperSettings(context) }, shape = RoundedCornerShape(12.dp)) {
                    Text("Для разработчиков")
                }
            }
        }

        StepBlock(3, "Разреши доступ Archon Client", done = setup == BackupManager.Setup.Ready, expanded = started) {
            Hint("Появится системное окно Shizuku. Нажми «Разрешить».")
            if (denied) {
                Hint("Доступ отклонён навсегда. Открой Shizuku → «Авторизованные приложения» и включи Archon Client.")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { BackupManager.requestPermission() },
                    shape = RoundedCornerShape(12.dp),
                ) { Text("Разрешить доступ") }
                if (denied) {
                    OutlinedButton(onClick = { openShizuku(context) }, shape = RoundedCornerShape(12.dp)) {
                        Text("Открыть Shizuku")
                    }
                }
            }
        }

    }

    SettingsCard("Подготовь Minecraft (один раз)") {
        Hint(
            "Archon видит только миры в хранилище «Внешнее». Если мир лежит в «Приложение», " +
                "Android и Minecraft прячут его от всех, и скопировать его нельзя.",
        )
        Hint(
            "1. Открой Minecraft → Настройки → Хранилище.\n" +
                "2. В пункте «Расположение файлов» выбери «Внешнее» (в английской версии: File Storage Location → External).\n" +
                "3. Создай новый мир. Старые миры из «Приложение» остаются там, Archon их не увидит.\n" +
                "4. Закрой Minecraft полностью и вернись в Archon.",
        )
    }
}

// ---------------------------------------------------------------- управление копиями

@Composable
private fun ManageSection(
    onRestore: (BackupManager.BackupInfo) -> Unit,
    onDelete: (BackupManager.BackupInfo) -> Unit,
) {
    val context = LocalContext.current
    val busy = BackupManager.busy
    val worlds = BackupManager.worlds
    val backups = BackupManager.backups

    SettingsCard("Состояние") {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Chip("Shizuku работает", Ok)
            if (busy) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                Text("Идёт работа…", fontSize = 13.sp)
            }
        }
        val message = BackupManager.lastMessage
        if (message.isNotBlank()) Text(message, fontSize = 13.sp)
        if (BackupManager.lastTime > 0) {
            Hint("Последняя проверка: ${fmtTime(BackupManager.lastTime)}")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { BackupManager.backupAll(context, force = true) },
                enabled = !busy && worlds.isNotEmpty(),
                shape = RoundedCornerShape(12.dp),
            ) { Text("Копировать сейчас") }
            OutlinedButton(
                onClick = { BackupManager.refresh(context) },
                enabled = !busy,
                shape = RoundedCornerShape(12.dp),
            ) { Text("Обновить") }
        }
        Hint("Копируй при закрытом Minecraft: пока идёт игра, файлы мира меняются, и копия может получиться неполной.")
    }

    if (BackupManager.worldsChecked && worlds.isEmpty()) {
        SettingsCard("Миры не найдены") {
            StepBlock(1, "Выбери «Внешнее» хранилище в Minecraft", done = false, expanded = true) {
                Hint(BackupManager.folderProblem ?: "В папке Minecraft пока нет миров.")
                Hint(
                    "Открой Minecraft → Настройки → Хранилище → «Расположение файлов» → «Внешнее», затем создай новый мир. " +
                        "Миры из хранилища «Приложение» без root скопировать нельзя. Если после переключения миры пропали " +
                        "из списка, это нормально: они остались в другом хранилище.",
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (!MinecraftLauncher.launch(context)) {
                                Toast.makeText(context, "Не удалось запустить Minecraft", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                    ) { Text("Открыть Minecraft") }
                    OutlinedButton(
                        onClick = { BackupManager.refresh(context) },
                        enabled = !busy,
                        shape = RoundedCornerShape(12.dp),
                    ) { Text("Проверить снова") }
                }
            }
        }
    }

    SettingsCard("Сколько копий хранить") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(3, 5, 10).forEach { n ->
                Pill("$n", AppSettings.backupKeep == n) { AppSettings.setBackupKeep(context, n) }
            }
        }
        Hint("Для каждого мира отдельно. Старые копии удаляются автоматически.")
    }

    if (worlds.isNotEmpty()) {
        SettingsCard("Твои миры") {
            worlds.forEach { w ->
                val last = backups.firstOrNull { it.id == w.id }?.time
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 8.dp)) {
                        Text(w.name, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                        Hint(
                            formatSize(w.size) + " · " +
                                (if (last != null) "копия: ${fmtTime(last)}" else "копий пока нет"),
                        )
                    }
                    OutlinedButton(
                        onClick = { BackupManager.backupOne(context, w.folder, force = true) },
                        enabled = !busy,
                        shape = RoundedCornerShape(12.dp),
                    ) { Text("Копия") }
                }
            }
        }
    }

    SettingsCard("Копии") {
        if (backups.isEmpty()) {
            Hint("Копий пока нет. Первая появится автоматически или нажми «Копировать сейчас».")
        } else {
            backups.take(40).forEach { b ->
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(b.world, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                    Hint(fmtTime(b.time) + " · " + formatSize(b.size))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { onRestore(b) }, enabled = !busy) { Text("Восстановить") }
                        TextButton(onClick = { onDelete(b) }, enabled = !busy) { Text("Удалить", color = Warn) }
                    }
                }
            }
            if (backups.size > 40) Hint("Показаны последние 40 копий.")
        }
    }
}
