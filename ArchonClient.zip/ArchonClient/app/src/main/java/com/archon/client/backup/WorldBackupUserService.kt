package com.archon.client.backup

import android.os.ParcelFileDescriptor
import android.os.Environment
import android.util.Base64
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Runs with Shizuku's shell identity. It only reads Minecraft's External world folder
 * and writes the selected SAF file descriptor supplied by the app.
 */
class WorldBackupUserService : IWorldBackupService.Stub() {
    override fun listWorlds(): Array<String> {
        return try {
            val root = worldRoot()
            if (!root.isDirectory) {
                return arrayOf("!ERROR:Папка миров не найдена. Проверьте, что в Minecraft выбрано хранилище «Внешнее».")
            }

            val worlds = root.listFiles()
                ?.asSequence()
                ?.filter { it.isDirectory && File(it, "level.dat").isFile }
                ?.sortedBy { it.name }
                ?.map { folder ->
                    val title = File(folder, "levelname.txt")
                        .takeIf { it.isFile }
                        ?.readText(Charsets.UTF_8)
                        ?.trim()
                        ?.takeIf { it.isNotEmpty() }
                        ?: folder.name
                    val encodedTitle = Base64.encodeToString(title.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                    "${folder.name}\t$encodedTitle"
                }
                ?.toList()
                .orEmpty()
            worlds.toTypedArray()
        } catch (error: Throwable) {
            arrayOf("!ERROR:${safeMessage(error)}")
        }
    }

    override fun exportWorld(folderName: String, output: ParcelFileDescriptor): String {
        return try {
            if (!folderName.matches(Regex("[A-Za-z0-9_+=-]+"))) {
                throw IOException("Некорректное имя папки мира")
            }

            val root = worldRoot().canonicalFile
            val world = File(root, folderName).canonicalFile
            if (world.parentFile != root || !world.isDirectory || !File(world, "level.dat").isFile) {
                throw IOException("Мир больше не найден или недоступен")
            }

            ZipOutputStream(
                BufferedOutputStream(ParcelFileDescriptor.AutoCloseOutputStream(output)),
            ).use { zip ->
                val visitedDirectories = mutableSetOf<String>()
                addDirectoryToZip(world, world, zip, visitedDirectories)
            }
            "OK"
        } catch (error: Throwable) {
            runCatching { output.close() }
            "ERROR:${safeMessage(error)}"
        }
    }

    override fun destroy() {
        System.exit(0)
    }

    private fun worldRoot(): File {
        val suffix = "Android/data/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds"
        val candidates = listOf(
            File(Environment.getExternalStorageDirectory(), suffix),
            File("/storage/emulated/0", suffix),
            File("/sdcard", suffix),
        )
        return candidates.firstOrNull { it.isDirectory } ?: candidates.first()
    }

    private fun addDirectoryToZip(
        worldRoot: File,
        current: File,
        zip: ZipOutputStream,
        visitedDirectories: MutableSet<String>,
    ) {
        val canonicalRoot = worldRoot.canonicalPath
        val canonicalCurrent = current.canonicalFile
        if (canonicalCurrent.path != canonicalRoot &&
            !canonicalCurrent.path.startsWith("$canonicalRoot${File.separator}")
        ) {
            throw IOException("Обнаружен путь за пределами папки мира")
        }
        if (!visitedDirectories.add(canonicalCurrent.path)) return

        val children = current.listFiles()?.sortedBy { it.name }
            ?: throw IOException("Не удалось прочитать папку мира")
        for (child in children) {
            val canonicalChild = child.canonicalFile
            if (canonicalChild.path != canonicalRoot &&
                !canonicalChild.path.startsWith("$canonicalRoot${File.separator}")
            ) {
                continue
            }
            if (child.isDirectory) {
                addDirectoryToZip(worldRoot, child, zip, visitedDirectories)
            } else if (child.isFile) {
                val relativePath = child.relativeTo(worldRoot).path.replace(File.separatorChar, '/')
                zip.putNextEntry(ZipEntry(relativePath))
                FileInputStream(child).use { input -> input.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    private fun safeMessage(error: Throwable): String =
        (error.message ?: error.javaClass.simpleName).replace('\n', ' ').take(240)
}