package com.archon.client.backup

import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Работает с правами оболочки (через Shizuku). Трогает только две папки:
 * миры Minecraft (Android/data/com.mojang.minecraftpe/.../minecraftWorlds) и папку копий Archon/Backups.
 * Пути приходят только в виде коротких имён, которые здесь проверяются, чужие пути принять нельзя.
 */
class WorldBackupUserService : IWorldBackupService.Stub() {

    // ---------- список миров ----------
    override fun listWorlds(): String {
        return try {
            val root = worldRoot() ?: return fail(
                "no_folder",
                "Папка миров Minecraft не найдена. В Minecraft выбери хранилище «Внешнее» и создай мир.",
            )
            val arr = JSONArray()
            val dirs = root.listFiles()
                ?.filter { it.isDirectory && validFolderName(it.name) && File(it, "level.dat").isFile }
                ?.sortedBy { it.name }
                .orEmpty()
            for (d in dirs) {
                arr.put(
                    JSONObject()
                        .put("folder", d.name)
                        .put("name", worldTitle(d))
                        .put("size", dirSize(d))
                        .put("modified", newestModified(d)),
                )
            }
            JSONObject().put("ok", true).put("worlds", arr).toString()
        } catch (e: Throwable) {
            fail("error", message(e))
        }
    }

    // ---------- создание копии ----------
    override fun backupWorld(folderName: String, keep: Int, force: Boolean): String {
        var temp: File? = null
        return try {
            if (!validFolderName(folderName)) return fail("bad_name", "Некорректное имя папки мира")
            val root = (worldRoot() ?: return fail("no_folder", "Папка миров Minecraft не найдена")).canonicalFile
            val world = File(root, folderName).canonicalFile
            if (world.parentFile != root || !world.isDirectory || !File(world, "level.dat").isFile) {
                return fail("gone", "Мир больше не найден")
            }

            val newest = newestModified(world)
            // Мир менялся меньше минуты назад: скорее всего, идёт игра. Копия получилась бы неполной.
            if (!force && System.currentTimeMillis() - newest < BUSY_MS) {
                return JSONObject().put("ok", true).put("skipped", "busy").toString()
            }

            val dir = backupDir()
            val idHex = hex(folderName)
            val existing = backupsFor(dir, idHex)
            if (!force && existing.isNotEmpty() && existing.first().lastModified() >= newest) {
                return JSONObject().put("ok", true).put("skipped", "unchanged").toString()
            }

            val size = dirSize(world)
            if (dir.usableSpace < size + MIN_FREE) return fail("no_space", "Не хватает места в памяти телефона")

            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            val finalFile = File(dir, "${safeTitle(worldTitle(world))}__${idHex}__$stamp.mcworld")
            val tmp = File(dir, finalFile.name + ".tmp")
            temp = tmp
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zip ->
                zip.setLevel(1) // файлы LevelDB уже сжаты, высокий уровень только замедлит
                addDirectoryToZip(world, world, zip, mutableSetOf())
            }
            if (!tmp.renameTo(finalFile)) throw IOException("Не удалось сохранить файл копии")
            temp = null

            // Оставляем только свежие копии этого мира
            backupsFor(dir, idHex).drop(keep.coerceAtLeast(1)).forEach { it.delete() }

            JSONObject().put("ok", true).put("file", finalFile.name).put("size", finalFile.length()).toString()
        } catch (e: Throwable) {
            temp?.delete()
            fail("error", message(e))
        }
    }

    // ---------- список копий ----------
    override fun listBackups(): String {
        return try {
            val dir = backupDir()
            val arr = JSONArray()
            dir.listFiles()
                ?.filter { it.isFile && it.name.endsWith(".mcworld") }
                ?.sortedByDescending { it.lastModified() }
                ?.forEach { f ->
                    val m = BACKUP_NAME.matchEntire(f.name) ?: return@forEach
                    arr.put(
                        JSONObject()
                            .put("file", f.name)
                            .put("world", m.groupValues[1])
                            .put("id", m.groupValues[2])
                            .put("size", f.length())
                            .put("time", f.lastModified()),
                    )
                }
            JSONObject().put("ok", true).put("backups", arr).toString()
        } catch (e: Throwable) {
            fail("error", message(e))
        }
    }

    // ---------- восстановление: всегда как НОВЫЙ мир, существующие миры не трогаем ----------
    override fun restoreBackup(fileName: String): String {
        var target: File? = null
        return try {
            val file = backupFile(fileName) ?: return fail("bad_name", "Копия не найдена")
            val root = (worldRoot() ?: return fail(
                "no_folder",
                "Папка миров Minecraft не найдена. Открой Minecraft, выбери хранилище «Внешнее» и создай любой мир.",
            )).canonicalFile

            ZipFile(file).use { zf ->
                val entries = Collections.list(zf.entries())
                if (entries.size > MAX_ENTRIES) throw IOException("В копии слишком много файлов")
                var total = 0L
                var hasLevel = false
                for (e in entries) {
                    val n = e.name
                    if (n.startsWith("/") || n.contains('\\') || n.split('/').any { it == ".." }) {
                        throw IOException("Копия содержит небезопасные пути")
                    }
                    if (n == "level.dat") hasLevel = true
                    total += e.size.coerceAtLeast(0)
                }
                if (!hasLevel) throw IOException("В файле нет данных мира (level.dat)")
                if (total > MAX_TOTAL) throw IOException("Копия слишком большая")
                if (root.usableSpace < total + MIN_FREE) throw IOException("Не хватает места в памяти телефона")

                val base = "Archon_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                var name = base
                var i = 1
                while (File(root, name).exists()) name = "${base}_${i++}"
                val dest = File(root, name)
                target = dest
                if (!dest.mkdirs()) throw IOException("Не удалось создать папку мира")
                val canonDest = dest.canonicalFile

                for (e in entries) {
                    val out = File(canonDest, e.name).canonicalFile
                    if (out.path != canonDest.path && !out.path.startsWith(canonDest.path + File.separator)) {
                        throw IOException("Копия содержит небезопасные пути")
                    }
                    if (e.isDirectory) {
                        out.mkdirs()
                        continue
                    }
                    out.parentFile?.mkdirs()
                    zf.getInputStream(e).use { input -> FileOutputStream(out).use { output -> input.copyTo(output) } }
                }

                // Помечаем название, чтобы отличать от оригинала в списке миров
                val title = File(canonDest, "levelname.txt")
                val original = if (title.isFile) title.readText().trim() else name
                title.writeText("$original (восстановлен)")
                target = null
                return JSONObject().put("ok", true).put("folder", name).put("name", "$original (восстановлен)").toString()
            }
        } catch (e: Throwable) {
            runCatching { target?.deleteRecursively() }
            fail("error", message(e))
        }
    }

    override fun deleteBackup(fileName: String): String {
        return try {
            val file = backupFile(fileName) ?: return fail("bad_name", "Копия не найдена")
            if (!file.delete()) throw IOException("Не удалось удалить файл")
            JSONObject().put("ok", true).toString()
        } catch (e: Throwable) {
            fail("error", message(e))
        }
    }

    override fun destroy() {
        System.exit(0)
    }

    // ---------- вспомогательное ----------
    private fun validFolderName(name: String): Boolean =
        name.isNotEmpty() && name != "." && name != ".." &&
            name.none { it == '/' || it == '\\' || it == '\t' || it == '\n' || it == '\r' || it == '\u0000' }

    @Suppress("DEPRECATION")
    private fun storageRoots(): List<File> =
        listOf(File("/storage/emulated/0"), File("/sdcard"), Environment.getExternalStorageDirectory())
            .filter { it.isDirectory }
            .distinctBy { it.absolutePath }

    private fun worldRoot(): File? {
        val suffix = "Android/data/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds"
        return storageRoots().map { File(it, suffix) }.firstOrNull { it.isDirectory }
    }

    private fun backupDir(): File {
        val base = storageRoots().firstOrNull() ?: throw IOException("Память телефона недоступна")
        val dir = File(base, "Archon/Backups")
        if (!dir.isDirectory && !dir.mkdirs()) throw IOException("Не удалось создать папку Archon/Backups")
        return dir
    }

    /** Файл копии по короткому имени. Только внутри папки копий, только .mcworld. */
    private fun backupFile(name: String): File? {
        if (name.isEmpty() || name.startsWith(".") || !name.endsWith(".mcworld")) return null
        if (name.any { it == '/' || it == '\\' || it == '\u0000' }) return null
        val dir = backupDir().canonicalFile
        val f = File(dir, name).canonicalFile
        return if (f.parentFile == dir && f.isFile) f else null
    }

    private fun backupsFor(dir: File, idHex: String): List<File> =
        dir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".mcworld") && it.name.contains("__${idHex}__") }
            ?.sortedByDescending { it.lastModified() }
            .orEmpty()

    private fun worldTitle(folder: File): String {
        val f = File(folder, "levelname.txt")
        val text = if (f.isFile) runCatching { f.readText(Charsets.UTF_8).trim() }.getOrNull() else null
        return text?.takeIf { it.isNotEmpty() } ?: folder.name
    }

    private fun safeTitle(title: String): String {
        val cleaned = buildString {
            for (c in title) append(if (c.isLetterOrDigit() || c == ' ' || c == '-' || c == '(' || c == ')') c else '_')
        }
        return cleaned.replace(Regex("_+"), "_").trim().trim('_').take(40).ifBlank { "world" }
    }

    private fun hex(s: String): String = s.toByteArray(Charsets.UTF_8).joinToString("") { "%02x".format(it) }

    private fun dirSize(d: File): Long = d.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    private fun newestModified(d: File): Long = d.walkTopDown().filter { it.isFile }.maxOfOrNull { it.lastModified() } ?: 0L

    private fun addDirectoryToZip(
        worldRoot: File,
        current: File,
        zip: ZipOutputStream,
        visited: MutableSet<String>,
    ) {
        val canonicalRoot = worldRoot.canonicalPath
        val canonicalCurrent = current.canonicalFile
        if (canonicalCurrent.path != canonicalRoot &&
            !canonicalCurrent.path.startsWith("$canonicalRoot${File.separator}")
        ) {
            throw IOException("Обнаружен путь за пределами папки мира")
        }
        if (!visited.add(canonicalCurrent.path)) return

        val children = current.listFiles()?.sortedBy { it.name }
            ?: throw IOException("Не удалось прочитать папку мира")
        for (child in children) {
            val canonicalChild = child.canonicalFile
            if (canonicalChild.path != canonicalRoot &&
                !canonicalChild.path.startsWith("$canonicalRoot${File.separator}")
            ) {
                continue
            }
            if (child.isDirectory) {
                addDirectoryToZip(worldRoot, child, zip, visited)
            } else if (child.isFile) {
                val relative = child.relativeTo(worldRoot).path.replace(File.separatorChar, '/')
                zip.putNextEntry(ZipEntry(relative))
                FileInputStream(child).use { input -> input.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }

    private fun fail(code: String, message: String): String =
        JSONObject().put("ok", false).put("code", code).put("message", message).toString()

    private fun message(error: Throwable): String =
        (error.message ?: error.javaClass.simpleName).replace('\n', ' ').take(240)

    private companion object {
        const val BUSY_MS = 60_000L
        const val MIN_FREE = 64L * 1024 * 1024
        const val MAX_ENTRIES = 200_000
        const val MAX_TOTAL = 8L * 1024 * 1024 * 1024
        val BACKUP_NAME = Regex("""^(.*?)__([0-9a-f]+)__(\d{8}-\d{6})\.mcworld$""")
    }
}
