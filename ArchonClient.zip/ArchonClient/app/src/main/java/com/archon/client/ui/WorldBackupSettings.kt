package com.archon.client.ui

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.IBinder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.archon.client.backup.IWorldBackupService
import com.archon.client.backup.WorldBackupUserService
import com.archon.client.settings.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.util.Base64

private const val SHIZUKU_BACKUP_PERMISSION_REQUEST = 7421

private data class BackupWorld(val folderName: String, val displayName: String)

@Composable
internal fun WorldBackupSettingsCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var worlds by remember { mutableStateOf<List<BackupWorld>>(emptyList()) }
    var service by remember { mutableStateOf<IWorldBackupService?>(null) }
    var pendingWorld by remember { mutableStateOf<BackupWorld?>(null) }
    var status by remember { mutableStateOf("Функция выключена и не обращается к файлам Minecraft.") }
    var pendingBind by remember { mutableStateOf(false) }

    val serviceArgs = remember(context) {
        Shizuku.UserServiceArgs(
            ComponentName(context, WorldBackupUserService::class.java),
        )
            .daemon(false)
            .processNameSuffix("world-backup")
            .version(1)
    }

    val connection = remember(context) {
        object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                val remote = if (binder == null) null else IWorldBackupService.Stub.asInterface(binder)
                service = remote
                if (remote == null) {
                    status = "Не удалось подключиться к Shizuku."
                    return
                }
                status = "Проверяю доступ к мирам…"
                scope.launch {
                    try {
                        val records = withContext(Dispatchers.IO) { remote.listWorlds().toList() }
                        val error = records.firstOrNull()?.takeIf { it.startsWith("!ERROR:") }
                        if (error != null) {
                            worlds = emptyList()
                            status = error.removePrefix("!ERROR:")
                        } else {
                            worlds = records.mapNotNull(::parseBackupWorld)
                            status = if (worlds.isEmpty()) {
                                "Миры не найдены. Для этой проверки нужно хранилище «Внешнее» в Minecraft."
                            } else {
                                "Найдено миров: ${worlds.size}. Выбери «Экспорт» у нужного мира."
                            }
                        }
                    } catch (error: Throwable) {
                        worlds = emptyList()
                        status = "Не удалось прочитать список миров: ${error.message ?: "ошибка Shizuku"}"
                    }
                }
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                service = null
                status = "Связь с Shizuku потеряна. Запусти Shizuku и попробуй снова."
            }
        }
    }

    fun bindBackupService() {
        try {
            status = "Подключаюсь к Shizuku…"
            Shizuku.bindUserService(serviceArgs, connection)
        } catch (error: Throwable) {
            status = "Не удалось подключиться к Shizuku: ${error.message ?: "ошибка"}"
        }
    }

    val permissionListener = remember {
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_BACKUP_PERMISSION_REQUEST) {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    pendingBind = true
                } else {
                    status = "Разрешение Shizuku не выдано. Экспорт остался выключен до твоего выбора."
                }
            }
        }
    }

    DisposableEffect(permissionListener) {
        Shizuku.addRequestPermissionResultListener(permissionListener)
        onDispose { Shizuku.removeRequestPermissionResultListener(permissionListener) }
    }

    DisposableEffect(connection, serviceArgs) {
        onDispose {
            runCatching { Shizuku.unbindUserService(serviceArgs, connection, true) }
            service = null
        }
    }

    LaunchedEffect(pendingBind) {
        if (pendingBind) {
            pendingBind = false
            bindBackupService()
        }
    }

    val createWorldDocument = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri: Uri? ->
        val selectedWorld = pendingWorld
        val remote = service
        pendingWorld = null
        if (uri == null || selectedWorld == null) {
            status = "Экспорт отменён."
        } else if (remote == null) {
            status = "Shizuku отключился. Сначала снова найди миры."
        } else {
            scope.launch {
                status = "Экспортирую «${selectedWorld.displayName}»… Не закрывай приложение."
                try {
                    val result = withContext(Dispatchers.IO) {
                        val descriptor = context.contentResolver.openFileDescriptor(uri, "w")
                            ?: error("Не удалось открыть выбранный файл")
                        descriptor.use { remote.exportWorld(selectedWorld.folderName, it) }
                    }
                    status = if (result == "OK") {
                        "Готово: «${selectedWorld.displayName}» экспортирован в выбранное место."
                    } else {
                        "Экспорт не завершён: ${result.removePrefix("ERROR:")}"
                    }
                } catch (error: Throwable) {
                    status = "Ошибка экспорта: ${error.message ?: "Shizuku отключился"}"
                }
            }
        }
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "РЕЗЕРВНАЯ КОПИЯ МИРОВ",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.primary,
            )
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).padding(end = 12.dp)) {
                    Text("Экспорт миров (тест)", fontSize = 15.sp)
                    Text(
                        "Выключено по умолчанию. Доступ только после ручного запуска Shizuku.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(
                    checked = AppSettings.worldBackupEnabled,
                    onCheckedChange = {
                        AppSettings.setWorldBackupEnabled(context, it)
                        worlds = emptyList()
                        service = null
                        if (!it) {
                            runCatching { Shizuku.unbindUserService(serviceArgs, connection, true) }
                        }
                        status = if (it) {
                            "Нажми «Найти миры» — доступ будет запрошен только тогда."
                        } else {
                            "Функция выключена и не обращается к файлам Minecraft."
                        }
                    },
                )
            }

            if (AppSettings.worldBackupEnabled) {
                Text(
                    "Тест работает только с мирами в хранилище «Внешнее». Хранилище «Приложение» без root недоступно. Файл сохранится через системный выбор места.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = {
                    worlds = emptyList()
                    try {
                        if (!Shizuku.pingBinder()) {
                            status = "Установи и запусти Shizuku, затем нажми «Найти миры» ещё раз."
                        } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                            bindBackupService()
                        } else {
                            status = "Подтверди запрос Shizuku на доступ для этой функции."
                            Shizuku.requestPermission(SHIZUKU_BACKUP_PERMISSION_REQUEST)
                        }
                    } catch (_: Throwable) {
                        status = "Установи Shizuku и запусти его. Доступ будет запрошен только при нажатии этой кнопки."
                    }
                }) {
                    Text("Найти миры")
                }
                Text(status, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                worlds.forEach { world ->
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Text(
                            world.displayName,
                            modifier = Modifier.weight(1f),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                        )
                        OutlinedButton(onClick = {
                            pendingWorld = world
                            createWorldDocument.launch("${world.displayName.toSafeFileName()}.mcworld")
                        }) {
                            Text("Экспорт")
                        }
                    }
                }
            }
        }
    }
}

private fun parseBackupWorld(record: String): BackupWorld? {
    val separator = record.indexOf('\t')
    if (separator <= 0) return null
    val folderName = record.substring(0, separator)
    val encodedTitle = record.substring(separator + 1)
    val title = runCatching {
        String(Base64.getDecoder().decode(encodedTitle), Charsets.UTF_8)
    }.getOrDefault(folderName)
    return BackupWorld(folderName, title.ifBlank { folderName })
}

private fun String.toSafeFileName(): String =
    replace(Regex("""[\\/:*?"<>|]"""), "_")
        .trim()
        .take(80)
        .ifBlank { "Minecraft world" }