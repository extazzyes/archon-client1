package com.archon.client.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import com.archon.client.backup.BackupManager
import com.archon.client.settings.AppSettings

/** Карточка в настройках: тумблер автоматических копий миров и краткий статус. */
@Composable
internal fun WorldBackupSettingsCard(onOpen: () -> Unit) {
    val context = LocalContext.current
    val on = AppSettings.worldBackupEnabled || BackupManager.wantEnable

    SettingsCard("Резервные копии миров") {
        SwitchRow(
            "Автоматическая копия миров",
            "Через Shizuku. Выключена, пока ты её не включишь",
            on,
        ) { checked ->
            BackupManager.setEnabled(context, checked)
            if (checked && BackupManager.wantEnable) onOpen() // Shizuku не готов: показываем инструкцию
        }
        if (on) {
            val status = when {
                BackupManager.wantEnable -> "Нужна настройка Shizuku. Открой инструкцию."
                BackupManager.setup != BackupManager.Setup.Ready -> "Копии на паузе: Shizuku не запущен."
                BackupManager.lastMessage.isNotBlank() -> BackupManager.lastMessage
                else -> "Работает. Копии делаются автоматически."
            }
            Text(status, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onOpen) { Text("Копии и инструкция") }
        }
    }
}
