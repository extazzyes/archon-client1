package com.archon.client.mods

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

enum class ModKind(val title: String, val exts: Set<String>) {
    Addons("Аддоны", setOf("mcpack", "mcaddon")),
    Worlds("Миры", setOf("mcworld", "mctemplate"));

    fun accepts(name: String) = name.substringAfterLast('.', "").lowercase() in exts
}

object ModsRepository {
    fun modsDir(context: Context): File = File(context.filesDir, "mods").also { it.mkdirs() }

    fun list(context: Context, kind: ModKind): List<File> =
        modsDir(context)
            .listFiles { f -> f.isFile && kind.accepts(f.name) }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun listAll(context: Context): List<File> =
        ModKind.entries.flatMap { list(context, it) }

    /** Копирует выбранный пользователем файл в библиотеку приложения. */
    fun importFromUri(context: Context, uri: Uri, kind: ModKind): Boolean {
        val name = File(displayName(context, uri) ?: return false).name
        if (!kind.accepts(name)) return false
        val dest = File(modsDir(context), name)
        val input = context.contentResolver.openInputStream(uri) ?: return false
        input.use { src -> dest.outputStream().use { src.copyTo(it) } }
        ModMeta.remove(context, name)
        return true
    }

    fun delete(context: Context, file: File) {
        file.delete()
        ModMeta.remove(context, file.name)
    }

    private fun displayName(context: Context, uri: Uri): String? =
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
}
