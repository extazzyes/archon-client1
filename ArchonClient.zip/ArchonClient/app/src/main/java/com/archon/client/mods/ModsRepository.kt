package com.archon.client.mods

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

enum class ModKind(val title: String, val exts: Set<String>) {
    Addons("Аддоны", setOf("mcpack", "mcaddon")),
    Worlds("Миры", setOf("mcworld", "mctemplate"));

    fun accepts(name: String) = name.substringAfterLast('.', "").lowercase() in exts
}

object ModsRepository {
    fun modsDir(context: Context): File = File(context.filesDir, "mods").also { it.mkdirs() }

    fun list(context: Context, kind: ModKind): List<File> =
        modsDir(context)
            .listFiles { f -> f.isFile && kind.accepts(f.name) }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()

    fun listAll(context: Context): List<File> =
        ModKind.entries.flatMap { list(context, it) }

    /** Свободное имя в папке: addon.mcpack, addon_2.mcpack, addon_3.mcpack… */
    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        var n = 2
        while (true) {
            f = File(dir, if (ext.isEmpty()) "${base}_$n" else "${base}_$n.$ext")
            if (!f.exists()) return f
            n++
        }
    }

    private fun sameContent(a: File, b: File): Boolean {
        if (a.length() != b.length()) return false
        a.inputStream().buffered().use { x ->
            b.inputStream().buffered().use { y ->
                while (true) {
                    val c = x.read()
                    if (c != y.read()) return false
                    if (c < 0) return true
                }
            }
        }
    }

    /**
     * Копирует выбранный пользователем файл в библиотеку приложения.
     * Сначала во временный файл: если проверка не пройдена, в библиотеке ничего не меняется
     * (раньше в этом случае удалялся и старый файл с тем же именем).
     */
    fun importFromUri(context: Context, uri: Uri, kind: ModKind): Boolean {
        val name = File(displayName(context, uri) ?: return false).name
        if (!kind.accepts(name)) return false
        val dir = modsDir(context)
        val tmp = File(dir, "$name.import")
        try {
            val input = context.contentResolver.openInputStream(uri) ?: return false
            input.use { src -> tmp.outputStream().use { src.copyTo(it) } }
            if (PackValidator.check(tmp, strict = false, name = name) != null) return false
            val existing = File(dir, name)
            if (existing.exists() && sameContent(existing, tmp)) return true // такой файл уже есть
            val dest = uniqueFile(dir, name)
            if (!tmp.renameTo(dest)) return false
            ModMeta.remove(context, dest.name)
            return true
        } finally {
            tmp.delete()
        }
    }

    fun delete(context: Context, file: File) {
        file.delete()
        ModMeta.remove(context, file.name)
    }

    private fun displayName(context: Context, uri: Uri): String? =
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
}
