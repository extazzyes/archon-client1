package com.archon.client.chat

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.archon.client.cloud.Account
import com.archon.client.cloud.ChatRow
import com.archon.client.cloud.Supa
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Чат через нашу базу Supabase (раньше был публичный ntfy.sh, где любой мог писать под чужим ником).
 * Читать могут все, писать — только игроки с профилем. Ник берётся из профиля самой базой.
 * Новые сообщения подтягиваются каждые пару секунд, пока открыта вкладка чата.
 */
object ChatClient {
    data class Message(val id: Long, val time: Long, val nick: String, val text: String, val author: String)

    enum class Status { Connecting, Online, Offline }

    private const val PREFS = "archon"
    const val DEFAULT_ROOM = "global"
    private const val POLL_MS = 2500L

    val messages = mutableStateListOf<Message>()

    var status by mutableStateOf(Status.Offline)
        private set
    var room by mutableStateOf(DEFAULT_ROOM)
        private set
    /** Скрытые игроки (id аккаунтов). */
    var hidden by mutableStateOf<Set<String>>(emptySet())
        private set

    private var job: Job? = null
    private var lastId = 0L
    private var lastSent = 0L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context) {
        val p = prefs(context)
        room = p.getString("chat_room", null) ?: DEFAULT_ROOM
        hidden = p.getStringSet("chat_hidden_users", emptySet())?.toSet() ?: emptySet()
    }

    fun cleanRoom(raw: String): String =
        raw.filter { (it.isLetterOrDigit() && it.code < 128) || it == '-' || it == '_' }.take(40).ifBlank { DEFAULT_ROOM }

    fun updateRoom(context: Context, newRoom: String) {
        val r = cleanRoom(newRoom)
        if (r == room) return
        room = r
        prefs(context).edit().putString("chat_room", r).apply()
        val wasRunning = job?.isActive == true
        stop()
        messages.clear()
        lastId = 0L
        if (wasRunning) start()
    }

    fun hide(context: Context, author: String) {
        if (author.isBlank()) return
        hidden = hidden + author
        prefs(context).edit().putStringSet("chat_hidden_users", hidden).apply()
    }

    fun unhideAll(context: Context) {
        hidden = emptySet()
        prefs(context).edit().putStringSet("chat_hidden_users", emptySet()).apply()
    }

    fun start() {
        if (job?.isActive == true) return
        status = Status.Connecting
        job = scope.launch {
            while (isActive) {
                try {
                    poll()
                    status = Status.Online
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    status = Status.Offline
                }
                delay(if (status == Status.Online) POLL_MS else POLL_MS * 2)
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        status = Status.Offline
    }

    /** Забирает новые сообщения. Если пока ждали ответа сменили комнату, ответ выбрасываем. */
    private suspend fun poll() {
        val r = room
        val after = lastId
        val rows = withContext(Dispatchers.IO) { Supa.chatMessages(r, after) }
        if (r != room) return
        add(rows)
    }

    private fun add(rows: List<ChatRow>) {
        rows.forEach { row ->
            if (row.id > lastId) lastId = row.id
            if (messages.none { it.id == row.id }) {
                messages.add(Message(row.id, row.time, row.nick, row.text, row.author))
            }
        }
        while (messages.size > 300) messages.removeAt(0)
    }

    /** Возвращает текст ошибки или null, если всё хорошо. */
    suspend fun send(context: Context, text: String): String? {
        val clean = text.trim().take(500)
        if (clean.isEmpty()) return null
        if (Account.session == null) return "Войди в аккаунт, чтобы писать в чат"
        if (Account.profile == null) return "Сначала создай профиль"
        val now = System.currentTimeMillis()
        if (now - lastSent < 1500) return "Не так быстро"
        lastSent = now
        return try {
            val r = room
            Account.authed(context) { token -> Supa.sendChat(token, r, clean) }
            runCatching { poll() } // сразу показываем своё сообщение
            null
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Account.friendly(e)
        }
    }
}
