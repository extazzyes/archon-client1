package com.archon.client.chat

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Чат без своего сервера: сообщения ходят через бесплатный публичный сервис ntfy.sh.
 * Комната = название «темы» на этом сервисе. Регистрация и ключи не нужны.
 */
object ChatClient {
    data class Message(val id: String, val time: Long, val nick: String, val text: String, val tag: String)

    enum class Status { Connecting, Online, Offline }

    private const val SERVER = "https://ntfy.sh"
    private const val PREFS = "archon"
    const val DEFAULT_ROOM = "global"

    val messages = mutableStateListOf<Message>()

    var status by mutableStateOf(Status.Offline)
        private set
    var nick by mutableStateOf("Игрок")
        private set
    var room by mutableStateOf(DEFAULT_ROOM)
        private set
    var hidden by mutableStateOf<Set<String>>(emptySet())
        private set

    var myTag: String = ""
        private set

    private var job: Job? = null
    private var conn: HttpURLConnection? = null
    private var lastId: String? = null
    private var lastSent = 0L
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context) {
        val p = prefs(context)
        nick = p.getString("chat_nick", null) ?: "Игрок${(1000..9999).random()}"
        room = p.getString("chat_room", null) ?: DEFAULT_ROOM
        myTag = p.getString("chat_tag", null) ?: UUID.randomUUID().toString().take(8)
        hidden = p.getStringSet("chat_hidden", emptySet())?.toSet() ?: emptySet()
        p.edit().putString("chat_nick", nick).putString("chat_tag", myTag).apply()
    }

    private fun topic() = "archon-$room"

    fun updateProfile(context: Context, newNick: String, newRoom: String) {
        val n = newNick.trim().take(20).ifBlank { nick }
        val r = newRoom.filter { it.isLetterOrDigit() && it.code < 128 || it == '-' || it == '_' }
            .take(40).ifBlank { DEFAULT_ROOM }
        val roomChanged = r != room
        nick = n
        room = r
        prefs(context).edit().putString("chat_nick", n).putString("chat_room", r).apply()
        if (roomChanged) {
            messages.clear()
            lastId = null
            stop()
            start()
        }
    }

    fun hide(context: Context, tag: String) {
        if (tag.isBlank()) return
        hidden = hidden + tag
        prefs(context).edit().putStringSet("chat_hidden", hidden).apply()
    }

    fun unhideAll(context: Context) {
        hidden = emptySet()
        prefs(context).edit().putStringSet("chat_hidden", emptySet()).apply()
    }

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (currentCoroutineContext().isActive) {
                try {
                    withContext(Dispatchers.Main) { status = Status.Connecting }
                    stream()
                } catch (e: Exception) {
                    // связь пропала, попробуем снова
                }
                if (!currentCoroutineContext().isActive) break
                withContext(Dispatchers.Main) { status = Status.Offline }
                delay(3000)
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        conn?.disconnect()
        conn = null
        status = Status.Offline
    }

    private suspend fun stream() {
        val since = lastId ?: "all"
        val c = URL("$SERVER/${topic()}/json?since=$since").openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 90000 // сервер шлёт сигнал «я жив» примерно раз в 45 секунд
        c.setRequestProperty("User-Agent", "ArchonClient")
        conn = c
        try {
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            c.inputStream.bufferedReader().use { reader ->
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isNotBlank()) handle(line)
                }
            }
        } finally {
            c.disconnect()
            conn = null
        }
    }

    private suspend fun handle(line: String) {
        val o = JSONObject(line)
        when (o.optString("event")) {
            "open" -> withContext(Dispatchers.Main) { status = Status.Online }
            "message" -> {
                val id = o.getString("id")
                lastId = id
                val msg = Message(
                    id = id,
                    time = o.optLong("time"),
                    nick = o.optString("title").ifBlank { "Игрок" },
                    text = o.optString("message"),
                    tag = o.optJSONArray("tags")?.optString(0).orEmpty(),
                )
                withContext(Dispatchers.Main) {
                    status = Status.Online
                    if (messages.none { it.id == id }) {
                        messages.add(msg)
                        if (messages.size > 300) messages.removeAt(0)
                    }
                }
            }
        }
    }

    /** Возвращает текст ошибки или null, если всё хорошо. */
    suspend fun send(text: String): String? = withContext(Dispatchers.IO) {
        val clean = text.trim().take(500)
        if (clean.isEmpty()) return@withContext null
        val now = System.currentTimeMillis()
        if (now - lastSent < 1500) return@withContext "Не так быстро"
        lastSent = now
        try {
            val c = URL(SERVER).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 15000
            c.readTimeout = 15000
            c.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject()
                .put("topic", topic())
                .put("message", clean)
                .put("title", nick)
                .put("tags", JSONArray().put(myTag))
                .toString()
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            c.disconnect()
            when (code) {
                200 -> null
                429 -> "Слишком много сообщений, подожди немного"
                else -> "Ошибка отправки ($code)"
            }
        } catch (e: Exception) {
            "Нет связи с сервером"
        }
    }
}
