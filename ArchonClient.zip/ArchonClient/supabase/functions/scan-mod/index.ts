// ArchonClient: серверная проверка загруженных модов.
// Supabase → Edge Functions → Deploy a new function → Via Editor → имя: scan-mod → вставить этот код → Deploy.
//
// Приложение вызывает её сразу после загрузки мода. Пока функция не скажет «approved»,
// мод видит только автор (это правило стоит в базе, см. security.sql).
// Проверка идёт на сервере, поэтому её нельзя обойти, даже имея открытый код приложения.
//
// Как хранятся файлы (с версии 0.8.5):
//  * игрок загружает мод в приватную корзину uploads (его видит только он);
//  * после проверки функция сама кладёт ИМЕННО проверенные байты в публичную корзину mods
//    (папка approved/), куда игроки писать не могут. Подменить проверенный файл больше нельзя.
//  * удаляет мод тоже функция (action: "delete"), потому что из mods игрок удалять не может.

import { createClient } from "npm:@supabase/supabase-js@2";
import { Inflate, unzipSync } from "npm:fflate@0.8.2";

const MAX_FILE = 50 * 1024 * 1024; // как лимит корзины
const MAX_ENTRIES = 30_000;
const MAX_UNPACKED = 1500 * 1024 * 1024; // по заголовкам архива
const MAX_RATIO = 150;
const MAX_DEPTH = 3;
const INSPECT_MAX = 20 * 1024 * 1024; // файлы крупнее не распаковываем для проверки байтов
const NESTED_MAX = 50 * 1024 * 1024;
const BUDGET = 100 * 1024 * 1024; // сколько всего можно распаковать за одну проверку (у бесплатной функции ~256 МБ памяти)
const HEAD = 4096; // столько первых байт каждого файла смотрим на признаки программы

const BAD_EXT = new Set([
  "apk", "apks", "xapk", "apkm", "aab", "dex", "odex", "oat", "vdex", "so", "jar", "class",
  "exe", "dll", "sys", "msi", "scr", "com", "pif", "cpl", "bat", "cmd", "vbs", "vbe", "wsf",
  "ps1", "psm1", "hta", "lnk", "reg", "sh", "bash", "elf", "run", "deb", "rpm", "dmg", "app",
  "rar", "7z", "cab", "iso",
]);
const BAD_NAMES = new Set(["androidmanifest.xml", "classes.dex", "resources.arsc"]);
const NESTED_EXT = new Set(["mcpack", "mcaddon", "mcworld", "mctemplate", "zip"]);
// большие файлы базы мира: их содержимое не распаковываем, это дорого и бессмысленно
const SKIP_BYTES_EXT = new Set(["ldb", "log", "png", "jpg", "jpeg", "tga", "ogg", "wav", "fsb", "mp3"]);

class Bad extends Error {}

type Stats = { entries: number; unpacked: number; budget: number; manifest: boolean; levelDat: boolean };

const extOf = (n: string) => (n.includes(".") ? n.slice(n.lastIndexOf(".") + 1).toLowerCase() : "");

const u16 = (b: Uint8Array, o: number) => b[o] | (b[o + 1] << 8);
const u32 = (b: Uint8Array, o: number) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;

/** Настоящий Windows-файл: «MZ» и по смещению из заголовка стоит подпись «PE». Просто «MZ» в начале данных ничего не значит. */
function isPE(b: Uint8Array): boolean {
  if (b.length < 64 || b[0] !== 0x4d || b[1] !== 0x5a) return false;
  const off = u32(b, 0x3c);
  if (off < 64 || off + 4 > b.length) return false;
  return b[off] === 0x50 && b[off + 1] === 0x45 && b[off + 2] === 0 && b[off + 3] === 0;
}

function isProgram(b: Uint8Array): boolean {
  if (b.length < 4) return false;
  const elf = b[0] === 0x7f && b[1] === 0x45 && b[2] === 0x4c && b[3] === 0x46;
  const dex = b[0] === 0x64 && b[1] === 0x65 && b[2] === 0x78 && b[3] === 0x0a;
  return elf || dex || isPE(b);
}

/** Первые 4 байта файла внутри архива: распаковываем только самое начало, а не весь файл. */
function headOf(data: Uint8Array, method: number, start: number, compSize: number): Uint8Array {
  const end = Math.min(data.length, start + compSize);
  if (method === 0) return data.subarray(start, Math.min(end, start + HEAD));
  if (method !== 8) throw new Bad("Архив сжат неизвестным способом");
  const out: number[] = [];
  const inf = new Inflate();
  inf.ondata = (chunk: Uint8Array) => {
    for (let i = 0; i < chunk.length && out.length < HEAD; i++) out.push(chunk[i]);
  };
  try {
    for (let p = start; p < end && out.length < HEAD; p += 1024) {
      const q = Math.min(end, p + 1024);
      inf.push(data.subarray(p, q), q >= end);
    }
  } catch (_) {
    throw new Bad("Архив повреждён");
  }
  return Uint8Array.from(out);
}

/**
 * Проверяет начало КАЖДОГО файла в архиве, в том числе картинок, звуков и больших файлов,
 * которые целиком не распаковываются. Так ловится программа, переименованная, например, в .png.
 */
function checkHeads(data: Uint8Array) {
  let e = -1;
  for (let i = data.length - 22; i >= Math.max(0, data.length - 22 - 65535); i--) {
    if (u32(data, i) === 0x06054b50) { e = i; break; }
  }
  if (e < 0) throw new Bad("Архив повреждён");
  const count = u16(data, e + 10);
  let p = u32(data, e + 16);
  if (count === 0xffff || p === 0xffffffff) throw new Bad("Такой формат архива (ZIP64) не поддерживается");
  for (let k = 0; k < count; k++) {
    if (p + 46 > data.length || u32(data, p) !== 0x02014b50) throw new Bad("Архив повреждён");
    const flags = u16(data, p + 8);
    const method = u16(data, p + 10);
    const comp = u32(data, p + 20);
    const nl = u16(data, p + 28), xl = u16(data, p + 30), cl = u16(data, p + 32);
    const local = u32(data, p + 42);
    const name = new TextDecoder().decode(data.subarray(p + 46, p + 46 + nl)).replace(/\\/g, "/");
    p += 46 + nl + xl + cl;
    if (name.endsWith("/")) continue;
    if (flags & 1) throw new Bad("Архивы с паролем не принимаются");
    if (comp === 0xffffffff || local === 0xffffffff) throw new Bad("Такой формат архива (ZIP64) не поддерживается");
    if (local + 30 > data.length || u32(data, local) !== 0x04034b50) throw new Bad("Архив повреждён");
    const start = local + 30 + u16(data, local + 26) + u16(data, local + 28);
    const base = name.split("/").pop()!.toLowerCase();
    const ext = extOf(base);
    if (NESTED_EXT.has(ext)) continue; // вложенные архивы проверяются отдельно, целиком
    if (isProgram(headOf(data, method, start, comp))) {
      throw new Bad(`Внутри спрятана программа: ${base.slice(0, 50)}`);
    }
  }
}

function inspect(data: Uint8Array, s: Stats, depth: number) {
  if (data.length < 4 || data[0] !== 0x50 || data[1] !== 0x4b) throw new Bad("Это не архив Minecraft");
  checkHeads(data);
  const declared = new Map<string, number>();
  let files: Record<string, Uint8Array>;
  try {
    files = unzipSync(data, {
      filter(f) {
        if (++s.entries > MAX_ENTRIES) throw new Bad("Слишком много файлов внутри архива");
        const name = f.name.replace(/\\/g, "/");
        const parts = name.split("/");
        if (name.startsWith("/") || parts.includes("..") || /^[A-Za-z]:/.test(name)) {
          throw new Bad("В архиве опасные пути файлов");
        }
        if (name.endsWith("/")) return false;
        const base = parts[parts.length - 1].toLowerCase();
        const ext = extOf(base);
        if (BAD_NAMES.has(base) || BAD_EXT.has(ext)) {
          throw new Bad(`Внутри есть программа (${parts[parts.length - 1].slice(0, 50)})`);
        }
        if (base === "manifest.json") s.manifest = true;
        if (base === "level.dat") s.levelDat = true;
        s.unpacked += f.originalSize;
        if (s.unpacked > MAX_UNPACKED) throw new Bad("Архив слишком большой после распаковки");
        declared.set(f.name, f.originalSize);

        const nested = NESTED_EXT.has(ext);
        const limit = nested ? NESTED_MAX : INSPECT_MAX;
        if (!nested && SKIP_BYTES_EXT.has(ext)) return false;
        if (f.originalSize > limit || s.budget - f.originalSize < 0) {
          if (nested) throw new Bad("Вложенный архив слишком большой для проверки");
          return false;
        }
        s.budget -= f.originalSize;
        return true;
      },
    });
  } catch (e) {
    if (e instanceof Bad) throw e;
    throw new Bad("Архив повреждён");
  }

  for (const [name, bytes] of Object.entries(files)) {
    // распаковалось больше, чем заявлено в заголовке — значит архив подделан
    if (bytes.length > (declared.get(name) ?? 0) + 1024) throw new Bad("Архив подделан (неверные размеры файлов)");
    const ext = extOf(name);
    if (NESTED_EXT.has(ext)) {
      if (depth + 1 > MAX_DEPTH) throw new Bad("Слишком много архивов друг в друге");
      inspect(bytes, s, depth + 1);
    } else if (isProgram(bytes.subarray(0, HEAD))) {
      throw new Bad(`Внутри спрятана программа: ${name.split("/").pop()?.slice(0, 50)}`);
    }
  }
}

async function sha256(data: Uint8Array): Promise<string> {
  const d = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** Необязательно: если в секретах функции задан VT_API_KEY, хэш файла сверяется с базой VirusTotal. */
async function virusTotal(hash: string): Promise<string | null> {
  const key = Deno.env.get("VT_API_KEY");
  if (!key) return null;
  try {
    const r = await fetch(`https://www.virustotal.com/api/v3/files/${hash}`, { headers: { "x-apikey": key } });
    if (r.status !== 200) return null; // файл там ещё не встречался
    const j = await r.json();
    const st = j?.data?.attributes?.last_analysis_stats ?? {};
    if ((st.malicious ?? 0) >= 2) return `Антивирусы VirusTotal считают файл вредным (${st.malicious})`;
  } catch (_) { /* VirusTotal недоступен — не мешаем загрузке */ }
  return null;
}

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, {
  auth: { persistSession: false },
});

async function scanOne(modId: string): Promise<{ status: string; reason: string }> {
  const { data: mod, error } = await db.from("mods").select("*").eq("id", modId).maybeSingle();
  if (error || !mod) return { status: "rejected", reason: "Мод не найден" };
  if (mod.status !== "pending") return { status: mod.status, reason: mod.scan_note ?? "" };

  let reason = "";
  let hash: string | null = null;
  let source = "";
  let bytes: Uint8Array | null = null;
  try {
    if (String(mod.file_path).split("/")[0] !== String(mod.owner)) throw new Bad("Файл лежит не в папке автора");
    const ext = extOf(String(mod.file_name));
    if (!["mcpack", "mcaddon", "mcworld", "mctemplate"].includes(ext)) throw new Bad("Такой тип файла не поддерживается");

    // новые моды лежат в приватной корзине uploads, старые (до 0.8.5) — в mods
    let blob: Blob | null = null;
    for (const b of ["uploads", "mods"]) {
      const { data: d } = await db.storage.from(b).download(mod.file_path);
      if (d) { blob = d; source = b; break; }
    }
    if (!blob) throw new Bad("Файл не найден в хранилище");
    if (blob.size > MAX_FILE) throw new Bad("Файл больше 50 МБ");
    bytes = new Uint8Array(await blob.arrayBuffer());
    blob = null; // копия в памяти больше не нужна

    hash = await sha256(bytes);
    const { data: banned } = await db.from("banned_hashes").select("sha256").eq("sha256", hash).maybeSingle();
    if (banned) throw new Bad("Этот файл уже был удалён как вредный");

    const s: Stats = { entries: 0, unpacked: 0, budget: BUDGET, manifest: false, levelDat: false };
    inspect(bytes, s, 0);
    if (s.unpacked > 100 * 1024 * 1024 && s.unpacked / Math.max(bytes.length, 1) > MAX_RATIO) {
      throw new Bad("Подозрительно сильно сжатый архив (похоже на zip-бомбу)");
    }
    if ((ext === "mcpack" || ext === "mcaddon") && !s.manifest) throw new Bad("Внутри нет manifest.json — это не аддон");
    if (ext === "mcworld" && !s.levelDat) throw new Bad("Внутри нет level.dat — это не мир");
    if (ext === "mctemplate" && !(s.levelDat && s.manifest)) throw new Bad("Это не похоже на шаблон мира");

    const vt = await virusTotal(hash);
    if (vt) throw new Bad(vt);
  } catch (e) {
    if (e instanceof Bad) {
      reason = e.message;
    } else {
      // сбой самой проверки (а не вредный файл): ничего не удаляем, мод остаётся «на проверке»
      return { status: "pending", reason: "Проверка пока не удалась, попробуй позже" };
    }
  }

  if (reason) {
    await db.from("mods").update({ status: "rejected", scan_note: reason, sha256: hash }).eq("id", modId);
    // вредный файл сразу убираем из хранилища, чтобы по прямой ссылке его тоже нельзя было скачать
    if (source) await db.storage.from(source).remove([mod.file_path]);
    return { status: "rejected", reason };
  }

  // Кладём в публичную корзину именно те байты, которые проверили (а не «тот файл, что лежит сейчас»:
  // его автор мог бы успеть подменить). Игроки в папку approved/ писать не могут.
  const ext = extOf(String(mod.file_name));
  const finalPath = `approved/${mod.id}.${ext}`;
  const { error: upErr } = await db.storage.from("mods").upload(finalPath, bytes!, {
    contentType: "application/octet-stream",
    upsert: true,
  });
  if (upErr) return { status: "pending", reason: "Не удалось сохранить проверенный файл, попробуй позже" };

  await db.from("mods").update({ status: "approved", scan_note: null, sha256: hash, file_path: finalPath }).eq("id", modId);
  if (source && !(source === "mods" && mod.file_path === finalPath)) {
    await db.storage.from(source).remove([mod.file_path]);
  }
  return { status: "approved", reason: "" };
}

/** Кто вызывает функцию: id пользователя по его токену. */
async function userId(req: Request): Promise<string | null> {
  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
  const { data } = await db.auth.getUser(token);
  return data?.user?.id ?? null;
}

/** Удаление мода автором: игрок сам не может удалить файл из публичной корзины mods. */
async function deleteOne(req: Request, modId: string): Promise<Response> {
  const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
  const { data: u } = await db.auth.getUser(token);
  const uid = u?.user?.id;
  if (!uid) return jsonResponse({ error: "Нужно войти в аккаунт" }, 401);
  const { data: mod } = await db.from("mods").select("*").eq("id", modId).maybeSingle();
  if (!mod) return jsonResponse({ ok: true }); // уже удалён
  if (String(mod.owner) !== uid) return jsonResponse({ error: "Можно удалять только свои моды" }, 403);
  await db.from("mods").delete().eq("id", modId);
  if (String(mod.file_path).startsWith("approved/")) {
    await db.storage.from("mods").remove([mod.file_path]);
  } else {
    await db.storage.from("uploads").remove([mod.file_path]);
    await db.storage.from("mods").remove([mod.file_path]);
  }
  if (mod.image_path) await db.storage.from("images").remove([mod.image_path]);
  return jsonResponse({ ok: true });
}

const jsonResponse = (o: unknown, code = 200) =>
  new Response(JSON.stringify(o), { status: code, headers: { "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  const json = jsonResponse;
  try {
    const body = await req.json().catch(() => ({}));

    if (body.action === "delete") {
      if (typeof body.mod_id !== "string" || body.mod_id.length > 64) return json({ error: "mod_id required" }, 400);
      return await deleteOne(req, body.mod_id);
    }

    // Перепроверить все моды «на проверке» (например, старые). Только с секретным ключом:
    // Edge Functions → scan-mod → Test → Authorization: service_role → body {"all_pending": true}
    if (body.all_pending === true) {
      const auth = req.headers.get("Authorization") ?? "";
      if (auth !== `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}`) return json({ error: "forbidden" }, 403);
      const { data } = await db.from("mods").select("id").eq("status", "pending").limit(100);
      const results = [];
      for (const m of data ?? []) results.push({ id: m.id, ...(await scanOne(m.id)) });
      return json({ results });
    }

    if (typeof body.mod_id !== "string" || body.mod_id.length > 64) return json({ error: "mod_id required" }, 400);
    // проверить мод может только его автор (иначе кто угодно мог бы гонять функцию вхолостую)
    const uid = await userId(req);
    if (!uid) return json({ error: "Нужно войти в аккаунт" }, 401);
    const { data: own } = await db.from("mods").select("owner").eq("id", body.mod_id).maybeSingle();
    if (!own) return json({ status: "rejected", reason: "Мод не найден" });
    if (String(own.owner) !== uid) return json({ error: "Проверять можно только свои моды" }, 403);
    return json(await scanOne(body.mod_id));
  } catch (_) {
    return json({ error: "internal" }, 500);
  }
});
