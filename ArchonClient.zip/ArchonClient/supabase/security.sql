-- ============================================================================
-- ArchonClient: защита облака модов, профилей и чата.
-- Запускать в Supabase → SQL Editor → New query → вставить всё → Run.
-- Скрипт можно запускать повторно, он ничего не ломает при втором запуске.
--
-- Зачем: код приложения открыт, ключ Supabase в нём публичный. Значит любой может
-- слать запросы в базу напрямую, мимо проверок в приложении. Поэтому правила
-- должны жить здесь, в самой базе, — их обойти нельзя.
-- ============================================================================

-- ---------- 1. Новые поля у модов ----------
alter table public.mods add column if not exists status    text not null default 'pending';
alter table public.mods add column if not exists scan_note text;
alter table public.mods add column if not exists sha256    text;
alter table public.mods add column if not exists reports   int  not null default 0;

do $$ begin
  alter table public.mods add constraint mods_status_check check (status in ('pending', 'approved', 'rejected'));
exception when duplicate_object then null; end $$;

create index if not exists mods_status_idx on public.mods (status);

-- Хэши файлов, которые точно вредные. Если удалишь мод с вирусом — добавь сюда его sha256,
-- и такой же файл больше никто не сможет загрузить.
create table if not exists public.banned_hashes (
  sha256     text primary key,
  note       text,
  created_at timestamptz not null default now()
);
alter table public.banned_hashes enable row level security; -- без политик: читать/писать может только сервер

-- ---------- 2. Защита полей модов ----------
-- Обычный пользователь (через приложение или напрямую через API) не может:
--  * сам поставить себе status = 'approved';
--  * накрутить скачивания или сбросить жалобы;
--  * подменить путь к файлу после проверки;
--  * загрузить мод от чужого имени или в чужую папку;
--  * подделать дату загрузки, чтобы обойти лимит 10 модов в сутки;
--  * менять чужие моды (это правило стоит в политике mods_update_own ниже).
create or replace function public.mods_guard() returns trigger
language plpgsql as $$
begin
  if current_user not in ('anon', 'authenticated') then
    return new; -- сервер (функция проверки, служебные функции) может всё
  end if;

  new.title := btrim(coalesce(new.title, ''));
  if char_length(new.title) not between 1 and 80 then
    raise exception 'Название мода: от 1 до 80 символов';
  end if;
  if char_length(coalesce(new.description, '')) > 600 then
    raise exception 'Описание мода слишком длинное (до 600 символов)';
  end if;
  if new.image_path is not null and (split_part(new.image_path, '/', 1) <> auth.uid()::text or new.image_path like '%..%') then
    raise exception 'Картинка должна лежать в твоей папке';
  end if;

  if tg_op = 'INSERT' then
    new.status     := 'pending';
    new.scan_note  := null;
    new.sha256     := null;
    new.downloads  := 0;
    new.reports    := 0;
    new.created_at := now(); -- иначе можно было указать старую дату и обойти лимит за сутки
    if auth.uid() is null or new.owner is distinct from auth.uid() then
      raise exception 'Загружать моды можно только от своего имени';
    end if;
    if split_part(new.file_path, '/', 1) <> auth.uid()::text or new.file_path like '%..%' then
      raise exception 'Файл мода должен лежать в твоей папке';
    end if;
    if new.kind is null or new.kind not in ('addon', 'world') then
      raise exception 'Неизвестный тип мода';
    end if;
    if (select count(*) from public.mods m where m.owner = auth.uid() and m.created_at > now() - interval '1 day') >= 10 then
      raise exception 'Слишком много загрузок за сутки, попробуй завтра';
    end if;
    return new;
  end if;

  -- UPDATE: автор может менять только название, описание и картинку.
  -- Скачивания считает функция count_download (она работает от имени сервера).
  if new.downloads  is distinct from old.downloads
     or new.status     is distinct from old.status
     or new.scan_note  is distinct from old.scan_note
     or new.sha256     is distinct from old.sha256
     or new.reports    is distinct from old.reports
     or new.owner      is distinct from old.owner
     or new.file_path  is distinct from old.file_path
     or new.file_name  is distinct from old.file_name
     or new.size       is distinct from old.size
     or new.kind       is distinct from old.kind
     or new.created_at is distinct from old.created_at then
    raise exception 'Эти поля мода менять нельзя';
  end if;
  return new;
end $$;

drop trigger if exists mods_guard on public.mods;
create trigger mods_guard before insert or update on public.mods
  for each row execute function public.mods_guard();

-- ---------- 3. Кто что видит в таблице модов (RLS) ----------
-- Удаляем все старые правила таблицы mods и ставим новые, чтобы не осталось «дыр».
alter table public.mods enable row level security;
do $$ declare p record; begin
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'mods' loop
    execute format('drop policy %I on public.mods', p.policyname);
  end loop;
end $$;

-- Чужие моды видны только проверенные и без 3+ жалоб. Свои — всегда (чтобы видеть статус проверки).
create policy mods_select on public.mods for select
  using ((status = 'approved' and reports < 3) or owner = auth.uid());
create policy mods_insert on public.mods for insert to authenticated
  with check (owner = auth.uid());
-- Удалять мод напрямую нельзя: проверенный файл лежит в публичной корзине, и если убрать только строку,
-- файл останется доступен по прямой ссылке. Автор удаляет мод через функцию scan-mod (action: "delete"):
-- она убирает и строку, и все файлы.
revoke delete on public.mods from authenticated;
-- Менять мод может только его автор (раньше любой мог переименовать чужой мод).
create policy mods_update_own on public.mods for update to authenticated
  using (owner = auth.uid()) with check (owner = auth.uid());

-- ---------- 4. Счётчик скачиваний ----------
-- Одно скачивание от одного аккаунта засчитывается один раз, поэтому накрутить нельзя.
create table if not exists public.mod_downloads (
  mod_id     text not null,
  user_id    uuid not null,
  created_at timestamptz not null default now(),
  primary key (mod_id, user_id)
);
alter table public.mod_downloads enable row level security; -- без политик: пишет только функция ниже

-- убираем старые варианты функции (с любыми параметрами)
do $$ declare f record; begin
  for f in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.proname = 'count_download' loop
    execute format('drop function %s', f.sig);
  end loop;
end $$;

create function public.count_download(mod_id text) returns void
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  added int;
begin
  if uid is null then return; end if;
  if not exists (select 1 from mods m where m.id::text = count_download.mod_id and m.status = 'approved') then
    return;
  end if;
  insert into mod_downloads (mod_id, user_id) values (count_download.mod_id, uid) on conflict do nothing;
  get diagnostics added = row_count;
  if added > 0 then
    update mods set downloads = downloads + 1 where id::text = count_download.mod_id;
  end if;
end $$;

revoke all on function public.count_download(text) from public, anon;
grant execute on function public.count_download(text) to authenticated;

-- ---------- 5. Жалобы ----------
alter table public.reports enable row level security;

-- одна жалоба от одного человека на один мод
delete from public.reports a using public.reports b
  where a.ctid < b.ctid and a.mod_id = b.mod_id and a.reporter = b.reporter;
create unique index if not exists reports_once on public.reports (mod_id, reporter);

do $$ declare p record; begin
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'reports' loop
    execute format('drop policy %I on public.reports', p.policyname);
  end loop;
end $$;
create policy reports_insert on public.reports for insert to authenticated
  with check (reporter = auth.uid());
create policy reports_select_own on public.reports for select to authenticated
  using (reporter = auth.uid());

-- Счётчик жалоб в моде считает сервер, а не приложение. Старые триггеры на reports убираем,
-- чтобы жалобы не считались дважды.
do $$ declare t record; begin
  for t in select tgname from pg_trigger where tgrelid = 'public.reports'::regclass and not tgisinternal loop
    execute format('drop trigger %I on public.reports', t.tgname);
  end loop;
end $$;

create or replace function public.reports_recount() returns trigger
language plpgsql security definer set search_path = public as $$
declare mid text;
begin
  mid := coalesce(new.mod_id, old.mod_id)::text;
  update public.mods set reports = (select count(*) from public.reports r where r.mod_id::text = mid)
    where id::text = mid;
  return null;
end $$;

create trigger reports_recount after insert or delete on public.reports
  for each row execute function public.reports_recount();

update public.mods m set reports = (select count(*) from public.reports r where r.mod_id::text = m.id::text);

-- ---------- 6. Профили ----------
-- Читать профили могут все, менять — только свой. Ник уникален без учёта регистра.
alter table public.profiles enable row level security;
do $$ declare p record; begin
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'profiles' loop
    execute format('drop policy %I on public.profiles', p.policyname);
  end loop;
end $$;
create policy profiles_select on public.profiles for select using (true);
create policy profiles_insert on public.profiles for insert to authenticated with check (id = auth.uid());
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

create or replace function public.profiles_guard() returns trigger
language plpgsql as $$
declare check_name boolean;
begin
  if current_user not in ('anon', 'authenticated') then
    return new;
  end if;
  if auth.uid() is null or new.id is distinct from auth.uid() then
    raise exception 'Можно менять только свой профиль';
  end if;
  new.username := btrim(coalesce(new.username, ''));
  if char_length(new.username) not between 3 and 20 or new.username ~ '[[:space:][:cntrl:]]' then
    raise exception 'Ник: от 3 до 20 символов, без пробелов';
  end if;
  -- Служебные ники занять нельзя (чтобы никто не выдавал себя за администрацию).
  -- Чужой ник при этом не трогаем: проверяем только новый профиль или смену ника.
  if tg_op = 'INSERT' then
    check_name := true;
  else
    check_name := new.username is distinct from old.username;
  end if;
  if check_name and regexp_replace(lower(new.username), '[_0-9]', '', 'g') in
     ('admin', 'administrator', 'moderator', 'mod', 'archon', 'archonclient', 'support', 'staff',
      'system', 'owner', 'root', 'minecraft', 'mojang') then
    raise exception 'Этот ник зарезервирован';
  end if;
  if char_length(coalesce(new.bio, '')) > 200 then raise exception 'Слишком длинное «О себе» (до 200 символов)'; end if;
  if char_length(coalesce(new.status, '')) > 40 then raise exception 'Слишком длинный статус (до 40 символов)'; end if;
  if new.avatar_path is not null and (split_part(new.avatar_path, '/', 1) <> auth.uid()::text or new.avatar_path like '%..%') then
    raise exception 'Аватарка должна лежать в твоей папке';
  end if;
  if new.banner_path is not null and (split_part(new.banner_path, '/', 1) <> auth.uid()::text or new.banner_path like '%..%') then
    raise exception 'Баннер должен лежать в твоей папке';
  end if;
  if coalesce(new.accent, 0) not between 0 and 5 then new.accent := 0; end if;
  if coalesce(new.frame, 0) not between 0 and 7 then new.frame := 0; end if;
  if tg_op = 'UPDATE' then new.created_at := old.created_at; end if;
  return new;
end $$;

drop trigger if exists profiles_guard on public.profiles;
create trigger profiles_guard before insert or update on public.profiles
  for each row execute function public.profiles_guard();

do $$ begin
  create unique index if not exists profiles_username_lower on public.profiles (lower(username));
exception when unique_violation then
  raise notice 'Есть игроки с одинаковыми никами (без учёта регистра). Переименуй одного и запусти скрипт ещё раз.';
end $$;

-- ---------- 7. Чат ----------
-- Раньше чат шёл через публичный ntfy.sh: туда мог писать кто угодно и под любым ником.
-- Теперь сообщения лежат в базе: писать могут только игроки с профилем, ник берётся из профиля.
create table if not exists public.chat_messages (
  id         bigint generated always as identity primary key,
  room       text not null check (room ~ '^[A-Za-z0-9_-]{1,40}$'),
  author     uuid not null,
  nick       text not null,
  text       text not null check (char_length(text) between 1 and 500),
  created_at timestamptz not null default now()
);
create index if not exists chat_messages_room_idx on public.chat_messages (room, id);
create index if not exists chat_messages_time_idx on public.chat_messages (created_at);
alter table public.chat_messages enable row level security;

do $$ declare p record; begin
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'chat_messages' loop
    execute format('drop policy %I on public.chat_messages', p.policyname);
  end loop;
end $$;
grant select on public.chat_messages to anon, authenticated;
grant insert, delete on public.chat_messages to authenticated;
create policy chat_select on public.chat_messages for select using (true);
create policy chat_insert on public.chat_messages for insert to authenticated with check (author = auth.uid());
create policy chat_delete_own on public.chat_messages for delete to authenticated using (author = auth.uid());

create or replace function public.chat_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare nk text;
begin
  if auth.uid() is null then raise exception 'Войди в аккаунт, чтобы писать в чат'; end if;
  select username into nk from profiles where id = auth.uid();
  if nk is null then raise exception 'Сначала создай профиль'; end if;
  new.author     := auth.uid();
  new.nick       := nk;
  new.text       := btrim(new.text);
  new.created_at := now();
  if exists (select 1 from chat_messages c where c.author = auth.uid() and c.created_at > now() - interval '1.5 seconds') then
    raise exception 'Не так быстро';
  end if;
  if (select count(*) from chat_messages c where c.author = auth.uid() and c.created_at > now() - interval '1 minute') >= 20 then
    raise exception 'Слишком много сообщений, подожди минуту';
  end if;
  -- иногда чистим сообщения старше недели, чтобы база не росла
  if random() < 0.02 then
    delete from chat_messages where created_at < now() - interval '7 days';
  end if;
  return new;
end $$;

drop trigger if exists chat_guard on public.chat_messages;
create trigger chat_guard before insert on public.chat_messages
  for each row execute function public.chat_guard();

-- ---------- 8. Хранилище файлов ----------
-- Новая схема:
--  * uploads (приватная) — сюда игрок загружает мод, пока он на проверке. Чужие его не видят и не скачают.
--  * mods (публичная) — сюда файл кладёт ТОЛЬКО сервер после проверки. Игрок не может ни удалить,
--    ни подменить его: раньше можно было удалить проверенный файл и залить вирус по тому же адресу.
--  * images (публичная) — картинки, игрок пишет только в свою папку.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('uploads', 'uploads', false, 52428800, array['application/octet-stream', 'application/zip'])
on conflict (id) do update set public = false,
  file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

update storage.buckets set file_size_limit = 52428800,
  allowed_mime_types = array['application/octet-stream', 'application/zip']
  where id = 'mods';
update storage.buckets set file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg', 'image/png', 'image/webp']
  where id = 'images';

do $$ declare p record; begin
  for p in
    select policyname from pg_policies
    where schemaname = 'storage' and tablename = 'objects'
      and (coalesce(qual, '') ~ '''(mods|images|uploads)''' or coalesce(with_check, '') ~ '''(mods|images|uploads)''')
  loop
    execute format('drop policy %I on storage.objects', p.policyname);
  end loop;

  create policy archon_upload_own on storage.objects for insert to authenticated
    with check (bucket_id in ('uploads', 'images') and (storage.foldername(name))[1] = auth.uid()::text);
  create policy archon_delete_own on storage.objects for delete to authenticated
    using (bucket_id in ('uploads', 'images') and (storage.foldername(name))[1] = auth.uid()::text);
  -- нужно, чтобы удаление работало; файлы mods и images и так публичные, uploads видит только автор
  create policy archon_read on storage.objects for select
    using (bucket_id in ('mods', 'images')
           or (bucket_id = 'uploads' and (storage.foldername(name))[1] = auth.uid()::text));
exception when insufficient_privilege then
  raise notice 'Правила хранилища не удалось поменять из SQL. Сделай их вручную: Storage → Policies (см. README.md).';
end $$;

-- Проверка: какие правила стоят сейчас
select schemaname, tablename, policyname, cmd from pg_policies
 where (schemaname = 'public' and tablename in ('mods', 'reports', 'profiles', 'chat_messages'))
    or (schemaname = 'storage' and tablename = 'objects')
 order by 1, 2, 3;
